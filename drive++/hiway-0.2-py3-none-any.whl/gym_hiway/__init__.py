from gym.envs.registration import register

register(
    id='hiway-v0',
    entry_point='gym_hiway.env.hiway_env:HiWayEnv',
)

register(
    id='hiway-competition-v0',
    entry_point='gym_hiway.env.competition_env:CompetitionEnv',
)
