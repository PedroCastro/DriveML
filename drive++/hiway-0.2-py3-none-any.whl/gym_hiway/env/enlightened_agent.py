from hiway.agent import Agent


class EnlightenedAgent(Agent):
    def setup(self, sim, agent_id, vehicle):
        vehicle.apply_brake(1.)
        print("'Ommmmmmmmmm ☯' - %s" % agent_id)

    def observation(self, sim, agent_id, vehicle):
        return None  # the eyes are closed

    def reward(self, sim, agent_id, vehicle):
        return 0.  # equanimity is it's own reward

    def perform_action(self, sim, agent_id, vehicle, action):
        pass  # why act?

    def is_done(self, sim, agent_id, vehicle):
        return False
