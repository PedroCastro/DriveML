import json
import multiprocessing
import threading
from collections import defaultdict

import numpy as np
from hiway.utils import unpack

try:
    import visdom
except ImportError:
    raise ImportError('Visdom is required for visualizations.')


def build_visdom_watcher_queue():
    # Set queue size to 1 so that we don't hang on too old observations
    obs_queue = multiprocessing.Queue(1)

    queue_watcher = threading.Thread(
        target=_watcher_loop,
        args=(obs_queue,),
        daemon=True # If False, the proc will not terminate until this thread stops
    )

    queue_watcher.start()

    return obs_queue


def _watcher_loop(obs_queue):
    def _vis_sim_obs(sim_obs):
        vis_images = defaultdict(list)
        for _, agent_obs in sim_obs.agent_observations.items():
            if agent_obs is None:
                continue

            ogm = getattr(agent_obs, 'occupancy_grid_map', None)
            if ogm is not None:
                image = ogm.data
                image = image.reshape(image.shape[0], image.shape[1])
                image = np.expand_dims(image, axis=0)
                image = (image.astype(np.float32) / 100) * 255
                vis_images['OGM'].append(image)

            image = getattr(agent_obs, 'ttc', None)
            if image is not None:
                image = image.reshape(image.shape[0], image.shape[1])
                image = np.expand_dims(image, axis=0)
                image = image.astype(np.float32) * 255
                image = np.kron(image, np.ones((10, 1)))
                vis_images['TTC'].append(image)

            image = getattr(agent_obs, 'top_down_rgb', None)
            if image is not None:
                image = image.transpose(2, 0, 1)
                image = image.astype(np.float32)
                vis_images['Top-Down RGB'].append(image)

        return vis_images

    vis = visdom.Visdom()

    while True:
        obs = obs_queue.get()

        for sim_id, sim_obs in obs.items():
            for key, images in _vis_sim_obs(sim_obs).items():
                title = {'Instace ID': sim_id, 'Type:': key}
                title = json.dumps(title)
                # images = np.stack(images, axis=0)
                # vis.images(images, win=sim_id + key, opts={'title': title})
                vis.images(images[0], win=sim_id + key, opts={'title': title})


def pprint_observations(observations):
    print(json.dumps(unpack(observations)))


def pprint_rewards(rewards):
    print(json.dumps(unpack(rewards)))
