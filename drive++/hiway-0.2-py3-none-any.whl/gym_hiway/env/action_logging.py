"""
The action log is a .txt file with a JSON object per line and follows the format,

# {"seed": ..., "episodes": ..., "iterations": ...}
{"episode": ..., "step": ..., "actions": ...}}
...
{"episode": ..., "step": ..., "actions": "DONE"}
...

The following is a valid example for a single instance with 2 agents,

# {"seed": 42, "max_step_length": 3}
{"actions": {"Instance 0": {"Agent 0": "forward", "Agent 1": "forward"}}}
{"actions": {"Instance 0": {"Agent 0": "turn_left", "Agent 1": "turn_right"}}}
{"actions": {"Instance 0": {"Agent 0": "forward", "Agent 1": "turn_right"}}}
{"actions": "DONE"}
{"actions": {"Instance 0": {"Agent 0": "forward", "Agent 1": "forward"}}}
{"actions": {"Instance 0": {"Agent 0": "turn_right", "Agent 1": "turn_left"}}}
{"actions": {"Instance 0": {"Agent 0": "forward", "Agent 1": "turn_left"}}}
{"actions": "DONE"}
"""

import os
import json
from datetime import datetime
from collections import namedtuple

ActionLogConfig = namedtuple(
    'ActionLogConfig', ['seed', 'max_step_length'])


class ActionLogReader:
    class EpisodeDone:
        pass

    def __init__(self, file_path):
        self._current_episode = 0
        self._current_iteration = 0
        self._open(file_path)

    def _open(self, file_path):
        file_path = os.path.expanduser(file_path)
        self._fp = open(file_path, 'r')
        self._config = self._read_header()

    def _read_header(self):
        header = self._fp.readline()
        if not header.startswith('#'):
            raise ValueError(
                "Action log must begin with a config header prefixed by '#'")

        try:
            params = json.loads(header[1:])
            return ActionLogConfig(**params)
        except KeyError:
            raise KeyError(
                'Invalid action log header keys. Must contain exactly  d'
                ', '.join(ActionLogConfig._fields))

    def next_actions(self):
        # `next` increments seek each time
        episode = self._current_episode
        iteration = self._current_iteration

        entry = json.loads(next(self._fp))

        if entry['actions'] == 'DONE':
            self._current_episode += 1
            self._current_iteration = 0
            return episode, iteration, ActionLogReader.EpisodeDone()

        self._current_iteration += 1

        return episode, iteration, entry['actions']

    def close(self):
        self._fp.close()

    @property
    def config(self):
        return self._config

    @staticmethod
    def is_done(actions_or_done):
        return isinstance(actions_or_done, ActionLogReader.EpisodeDone)


class ActionLogWriter:
    def __init__(self, config, dir_path):
        self._config = config

        file_path = os.path.join(dir_path, self._unique_filename())
        self._open(file_path)
        self._write_config(config)

    def _open(self, path):
        path = os.path.expanduser(path)
        dir_path = os.path.dirname(path)
        if not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)

        self._fp = open(path, 'w')

    def _unique_filename(self):
        return datetime.now().strftime(
            '{}_%d-%m-%Y_%I-%M-%S_%p.txt'.format(self._config.seed))

    def _write_config(self, config):
        assert self._fp.tell() == 0, 'Action log config must be the first written line'
        self._fp.write('# {}\n'.format(json.dumps(config._asdict())))

    def next_actions(self, actions):
        entry = dict(actions=actions)
        entry = json.dumps(entry)
        self._fp.write('{}\n'.format(entry))

    def mark_done(self):
        entry = dict(actions='DONE')
        entry = json.dumps(entry)
        self._fp.write('{}\n'.format(entry))

    def close(self):
        self._fp.close()
