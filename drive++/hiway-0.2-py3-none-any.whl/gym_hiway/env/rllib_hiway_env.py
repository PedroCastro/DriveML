import uuid
import logging

from ray.rllib.env.multi_agent_env import MultiAgentEnv

import hiway
from hiway.game_engine import GameEngine
from hiway.bullet_simulation import BulletSimulation
from hiway.sumo_traffic_simulation import SumoTrafficSimulation

logging.basicConfig(level=logging.INFO)

# XXX: Only supports a single HiWay simulation per environment
INSTANCE_ID = 'Instance 0'


class RLlibHiWayEnv(MultiAgentEnv):
    def __init__(self, config):
        self._sumo_scenario = config['sumo_scenario']
        self._agent_configs = config['agent_configs']
        self._headless = config.get('headless', False)
        self._game_engine = None
        hiway.seed(config.get('seed', 42))

    def step(self, agent_actions):
        agent_actions = {INSTANCE_ID: agent_actions}
        observations, rewards, dones = self._game_engine.step(agent_actions)

        # XXX: Since we are just looking at a single instance
        observations = observations[INSTANCE_ID].agent_observations
        rewards = rewards[INSTANCE_ID].agent_rewards
        dones = dones[INSTANCE_ID]

        # XXX: When any agent is done end the entire episode, otherwise we
        #      get a "Batches sent to postprocessing must only contain steps
        #      from a single trajectory" error.
        dones['__all__'] = any(dones.values())

        return observations, rewards, dones, {}

    def reset(self):
        # Defer expensive environment creation to prevent the driver process
        # from creating its own game engine.
        # https://ray.readthedocs.io/en/latest/rllib-env.html#expensive-environments
        if self._game_engine is None:
            self._game_engine = self._build_game_engine()
            self._game_engine.setup()

        observations = self._game_engine.reset()
        return observations[INSTANCE_ID].agent_observations

    def close(self):
        self._game_engine.teardown()

    def _build_game_engine(self):
        def sim_setup(sim):
            sim.add_road_network_from_egg(self._sumo_scenario.map_egg_filepath)

            for agent_id, agent_config in self._agent_configs.items():
                # XXX: Can't reuse agent name upon reset.
                #      https://github.com/ray-project/ray/issues/4526
                agent_id = '{}-{}'.format(agent_id, str(uuid.uuid4())[:8])
                agent = agent_config['agent_type']
                pos_on_start = agent_config.get('position_on_start', 'random')
                if pos_on_start == 'random':
                    wp = sim.traffic_sim.waypoints.random_waypoint()
                    wp_x, wp_y = wp.pos
                    pos = (wp_x, wp_y, 1.)
                    heading = wp.heading
                elif agent_config.get('snap_to_lane_on_start', True):
                    x, y, z = pos_on_start
                    wp = sim.traffic_sim.waypoints.closest_waypoint((x, y))
                    wp_x, wp_y = wp.pos
                    pos = (wp_x, wp_y, 1.)
                    heading = wp.heading
                else:
                    pos = pos_on_start
                    heading = agent_config.get('heading_on_start', 0.),

                agent = agent_config.get('agent_type')
                vehicle = sim.make_vehicle(pos, heading)
                sim.add_agent(agent_id, agent, vehicle)

        timestep_sec = 0.1
        traffic_sim = SumoTrafficSimulation(
            headless=True,
            scenario=self._sumo_scenario,
            time_resolution=timestep_sec)

        bullet_sim = BulletSimulation(sim_setup,
                                      traffic_sim,
                                      dimension_hints=(250, 100))

        game_engine = GameEngine(headless=self._headless,
                                 timestep_sec=timestep_sec)
        game_engine.add_simulation(INSTANCE_ID, bullet_sim)
        return game_engine
