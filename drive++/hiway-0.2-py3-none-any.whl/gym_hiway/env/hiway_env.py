import logging

import gym

from hiway.game_engine import GameEngine
from hiway.bullet_simulation import BulletSimulation
from hiway.sumo_traffic_simulation import SumoTrafficSimulation
from hiway.sumo_scenario import SumoScenario

from .simple_agent import SimpleAgent
from .visualization import build_visdom_watcher_queue

logging.basicConfig(level=logging.INFO)

class HiWayEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self,
                 sumo_scenario: SumoScenario,
                 agent_configs,
                 instance_ids,
                 visdom=False,
                 headless=False,
                 max_step_length=5000,
                 timestep_sec=0.01):
        self._max_step_length = max_step_length
        self._step_length = 0

        self._visdom_obs_queue = None
        if visdom:
            print('Running with visdom')
            self._visdom_obs_queue = build_visdom_watcher_queue()

        def sim_setup(sim):
            sim.add_road_network_from_egg(sumo_scenario.map_egg_filepath)

            for agent_id, agent_config in agent_configs.items():
                pos_on_start = agent_config.get('position_on_start', 'random')
                if pos_on_start == 'random':
                    wp = sim.traffic_sim.waypoints.random_waypoint()
                    wp_x, wp_y = wp.pos
                    pos = (wp_x, wp_y, 1.)
                    heading = wp.heading
                elif agent_config.get('snap_to_lane_on_start', True):
                    x, y, z = pos_on_start
                    wp = sim.traffic_sim.waypoints.closest_waypoint((x, y))
                    wp_x, wp_y = wp.pos
                    pos = (wp_x, wp_y, 1.)
                    heading = wp.heading
                else:
                    pos = pos_on_start
                    heading = agent_config.get('heading_on_start', 0.),

                agent = agent_config.get('agent_type')
                vehicle = sim.make_vehicle(pos, heading)
                sim.add_agent(agent_id, agent, vehicle)

        self._engine = GameEngine(headless=headless, timestep_sec=timestep_sec)

        for instance_id in instance_ids:
            traffic_sim = SumoTrafficSimulation(
                headless=headless,
                scenario=sumo_scenario,
                time_resolution=timestep_sec)

            bullet_sim = BulletSimulation(sim_setup,
                                          traffic_sim,
                                          dimension_hints=(250, 100))

            self._engine.add_simulation(instance_id, bullet_sim)

        self._engine.setup()

    def step(self, agent_actions):
        observation, reward, agent_dones = self._engine.step(agent_actions)

        self._try_emit_visdom_obs(observation)

        all_agents_done = all([
            agent_dones[sim_id][agent_id]
            for sim_id in agent_dones
            for agent_id in agent_dones[sim_id]
        ])

        self._step_length += 1
        if self._step_length >= self._max_step_length:
            all_agents_done = True

        agent_dones['__all__'] = all_agents_done
        return observation, reward, agent_dones, {}

    def reset(self):
        self._step_length = 0
        obs = self._engine.reset()

        self._try_emit_visdom_obs(obs)
        return obs

    def render(self, mode='human'):
        pass

    def close(self):
        if self._engine is not None:
            self._engine.destroy()

    def _try_emit_visdom_obs(self, obs):
        try:
            if self._visdom_obs_queue:
                self._visdom_obs_queue.put(obs, block=False)
        except Exception:
            print("dropped visdom frame instead of blocking")
