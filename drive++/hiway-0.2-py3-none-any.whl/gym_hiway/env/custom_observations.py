from hiway.vehicle import Vehicle
from hiway.bullet_simulation import BulletSimulation

import numpy as np
import math


def ttc_grid(sim: BulletSimulation,
             agent_id: str,
             ego: Vehicle,
             time_quantization: float,
             time_horizon: float) -> np.ndarray:
    """
    Compute time to collide assuming vehicles don't change lanes or velocities
    e.g. if the ego is in the right most lane on a 3 lane road with settings:
        time_quantization=1 (second)
        time_horizon=7 (seconds)
    we receive:
        [[0, 0, 0, 0, 1, 0, 0],
         [0, 0, 0, 0, 0, 0, 0],
         [0, 0, 0, 0, 0, 0, 0]]
    which tells us a collision is predicted in 5 seconds
    """

    road_network = sim.traffic_sim.road_network
    x, y, _ = ego.position
    ego_lane = road_network.nearest_lane((x, y), radius=1)

    if ego_lane is None:
        # ego is off road
        return None

    ego_offset = road_network.offset_into_lane(ego_lane, (x, y))

    social_vehicles = sim.neighborhood_vehicles_around_agent(agent_id, radius=100)

    ego_lane_idx = [lane_idx for lane_idx, lane
                    in enumerate(ego_lane.getEdge().getLanes())
                    if lane == ego_lane][0]

    number_of_lanes_on_edge = ego_lane.getEdge().getLaneNumber()
    look_ahead = int(time_horizon / time_quantization)
    grid = np.zeros((number_of_lanes_on_edge, look_ahead), dtype=np.uint8)
    for social_vehicle in social_vehicles:
        sv_x, sv_y, _ = social_vehicle.position
        sv_lane = road_network.nearest_lane((sv_x, sv_y), radius=1)

        if sv_lane is None:
            continue # this vehicle is off road

        if sv_lane.getID() != ego_lane.getID():
            continue # this vehicle is not on the same lane

        rel_speed_kmh = social_vehicle.speed - ego.speed
        rel_speed_meters_per_second = rel_speed_kmh * (1000 / (60 * 60))

        sv_offset = road_network.offset_into_lane(sv_lane, (sv_x, sv_y))
        distance_between_vehicles_meters = ego_offset - sv_offset

        if math.isclose(abs(rel_speed_meters_per_second), 0.):
            # these vehicles are moving at the same speed, no collision possible
            continue

        ttc = distance_between_vehicles_meters / rel_speed_meters_per_second
        if ttc > 0 and ttc < time_horizon:
            ttc_quantized = int(ttc / time_quantization)
            grid[ego_lane_idx, ttc_quantized] = 1
        else:
            # either collision is predicted to have happened in the past
            # or the collision is beyond our time horizon
            pass

    return grid
