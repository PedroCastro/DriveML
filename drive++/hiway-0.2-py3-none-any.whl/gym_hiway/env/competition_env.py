import logging

import gym

import hiway
from hiway.game_engine import GameEngine
from hiway.bullet_simulation import BulletSimulation
from hiway.sumo_traffic_simulation import SumoTrafficSimulation
from hiway.sumo_scenario import SumoScenario

from .simple_agent import SimpleAgent
from .visualization import build_visdom_watcher_queue

logging.basicConfig(level=logging.INFO)

_INSTANCE_ID = "INSTANCE-0"
_AGENT_ID = "AGENT-0"


AGENT_CONFIG = {
    "AGENT-0": {
        'position_on_start': 'random',
        'agent_type': SimpleAgent(debug=True)
    }
}


def default_action_function(action):
    return action


def default_obs_function(obs):
    return obs


def default_reward_function(obs, reward):
    return reward


class CompetitionEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, config):
        """
        config schema:
        {
          "max_step_length": Int or None (default: None), maxsteps per episode, set to None for no max
          "visdom": bool (False): whether or not to enable visdom visualization.
          "headless": bool (False): disable gui.
          "seed": int (0): RNG Seed
          "sumo_scenario": SumoScenario (defaults to scenarios/loop): the scenario to run.
          "reward_function": function to shape reward returned by the environment
          "observation_function": function to shape observation returned by the environment
          "action_function": function to translate policy action space to environment action space
          "observation_space": The gym.Space of the observation_function output.
          "action_space": The gym.Space of the action_function input.
        }
        """
        self._step_length = 0
        self._max_step_length = config.get('max_step_length', None)
        self._reward_function = \
            config.get('reward_function', default_reward_function)
        self._observation_function = \
            config.get('observation_function', default_obs_function)
        self._action_function = \
            config.get('action_function', default_action_function)

        self.observation_space = \
            config.get('observation_space', SimpleAgent.observation_space())

        self.action_space = \
            config.get('action_space', SimpleAgent.action_space())

        headless = config.get('headless', False)
        hiway.seed(config.get('seed', 0))

        sumo_scenario = config.get('sumo_scenario', None)
        if sumo_scenario is None:
            sumo_scenario = SumoScenario(
                'scenarios/loop',
                random_social_vehicle_count=10)

        self._visdom_obs_queue = None
        if config.get('visdom', False):
            print('Running with visdom')
            self._visdom_obs_queue = build_visdom_watcher_queue()

        def sim_setup(sim):
            sim.add_road_network_from_egg(sumo_scenario.map_egg_filepath)

            for agent_id, agent_config in AGENT_CONFIG.items():
                pos_on_start = agent_config.get('position_on_start', 'random')
                if pos_on_start == 'random':
                    wp = sim.traffic_sim.waypoints.random_waypoint()
                    wp_x, wp_y = wp.pos
                    pos = (wp_x, wp_y, 1.)
                    heading = wp.heading
                elif agent_config.get('snap_to_lane_on_start', True):
                    x, y, z = pos_on_start
                    wp = sim.traffic_sim.waypoints.closest_waypoint((x, y))
                    wp_x, wp_y = wp.pos
                    pos = (wp_x, wp_y, 1.)
                    heading = wp.heading
                else:
                    pos = pos_on_start
                    heading = agent_config.get('heading_on_start', 0.),

                agent = agent_config.get('agent_type')
                if headless:
                    # we don't want the visual debug overhead when headless
                    agent.debug = False

                vehicle = sim.make_vehicle(pos, heading)
                sim.add_agent(agent_id, agent, vehicle)

        timestep_sec = 0.1
        traffic_sim = SumoTrafficSimulation(
            headless=True,
            scenario=sumo_scenario,
            time_resolution=timestep_sec)

        bullet_sim = BulletSimulation(sim_setup,
                                      traffic_sim,
                                      dimension_hints=(250, 100))

        self._engine = GameEngine(headless=headless,
                                  timestep_sec=timestep_sec)
        self._engine.add_simulation(_INSTANCE_ID, bullet_sim)
        self._engine.setup()

    def step(self, agent_action):
        agent_action = self._action_function(agent_action)

        action_msg = {_INSTANCE_ID: {_AGENT_ID: agent_action}}
        observation, reward, agent_dones = self._engine.step(action_msg)

        self._try_emit_visdom_obs(observation)

        agent_done = agent_dones[_INSTANCE_ID][_AGENT_ID]
        agent_obs = observation[_INSTANCE_ID].agent_observations[_AGENT_ID]
        agent_reward = reward[_INSTANCE_ID].agent_rewards[_AGENT_ID]

        self._step_length += 1
        if self._max_step_length is not None and \
            self._step_length >= self._max_step_length:
            agent_done = True

        reward = self._reward_function(agent_obs, agent_reward)
        obs = self._observation_function(agent_obs)
        return obs, reward, agent_done, {}

    def reset(self):
        self._step_length = 0
        obs = self._engine.reset()
        self._try_emit_visdom_obs(obs)

        agent_obs = obs[_INSTANCE_ID].agent_observations[_AGENT_ID]
        return self._observation_function(agent_obs)

    def render(self, mode='human'):
        pass

    def close(self):
        if self._engine is not None:
            self._engine.destroy()

    def _try_emit_visdom_obs(self, obs):
        try:
            if self._visdom_obs_queue:
                self._visdom_obs_queue.put(obs, block=False)
        except Exception:
            print("dropped visdom frame instead of blocking")
