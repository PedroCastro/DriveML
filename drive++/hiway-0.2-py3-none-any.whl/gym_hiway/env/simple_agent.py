import math
from collections import namedtuple
import logging

import numpy as np
import gym

from hiway.utils.math import trimf, degrees_to_vec
from hiway.vehicle import Vehicle
from hiway.agent import Agent


Observation = namedtuple(
    'Observation',
    ['ego_vehicle_state',
     'neighborhood_vehicle_states',
     'top_down_rgb',
     'occupancy_grid_map',
     'waypoint_paths'])


class SimpleAgent(Agent):
    @staticmethod
    def observation_space():
        return None
        # We can't return a fixed observation space because we expose some non-fixed observations (ie. object list / waypoints)
        # return gym.spaces.Dict({
        #     "ego_vehicle_state": gym.spaces.Dict({
        #         # TODO: we should normalize heading to -180..180
        #         'heading': gym.spaces.Box(low=-360, high=360, shape=(1,)),
        #         'speed': gym.spaces.Box(low=-1e10, high=1e10, shape=(1,)),
        #         'throttle': gym.spaces.Box(low=0., high=1, shape=(1,)),
        #         'brake': gym.spaces.Box(low=0., high=1, shape=(1,)),
        #         'steering': gym.spaces.Box(low=-50, high=50, shape=(1,)),
        #         'position': gym.spaces.Box(low=-1e10, high=1e10, shape=(3,)),
        #         'bounding_box': gym.spaces.Dict({
        #             "width": gym.spaces.Box(low=-1e10, high=1e10, shape=(1,)),
        #             "length": gym.spaces.Box(low=-1e10, high=1e10, shape=(1,)),
        #             "height": gym.spaces.Box(low=-1e10, high=1e10, shape=(1,))
        #         })
        #     }),
        #     "waypoint_paths": ...
        # })

    @staticmethod
    def action_space():
        return gym.spaces.Box(low=np.array([0, 0, -45]),
                              high=np.array([1, 1, 45]),
                              dtype=np.float32)

    def setup(self, sim, agent_id, vehicle):
        self._log = logging.getLogger(self.__class__.__name__)

        vehicle.init_observation_ogm(64, 64, .25)
        vehicle.init_observation_rgb(256, 256, .1)

        waypoint_paths = sim.traffic_sim.waypoints.waypoint_paths_at(
            vehicle.position, lookahead=1)

        self._collected_wps = [waypoint_paths[0][0]]
        self._dist_travelled = 0.
        self._last_dist_travelled = 0.

    def observation(self, sim, agent_id, vehicle):
        ego = vehicle.state()
        neighborhood_vehicles = \
            sim.neighborhood_vehicles_around_agent(agent_id, radius=50)
        rgb = vehicle.calc_observation_rgb()
        ogm = vehicle.calc_observation_ogm()

        waypoint_paths = sim.traffic_sim.waypoints.waypoint_paths_at(
            vehicle.position, lookahead=50)

        if self.debug:
            for i, path in enumerate(waypoint_paths):
                # color paths to show ordering (red -> blue => right -> left)
                p = (i + 1) / len(waypoint_paths)
                sim.render_waypoint_path(path, color=(1. - p, 0., p, 1.))

        canonical_wp = waypoint_paths[0][0]
        if self._collected_wps[-1].id != canonical_wp.id:
            self._dist_travelled += self._compute_additional_dist_travelled(canonical_wp)
            self._collected_wps.append(canonical_wp)

        if self.debug:
            sim.render_waypoint_path(
                self._collected_wps, color=(0., 1., 0., 1.))

        return Observation(
            ego_vehicle_state=ego,
            neighborhood_vehicle_states=neighborhood_vehicles,
            top_down_rgb=rgb,
            occupancy_grid_map=ogm,
            waypoint_paths=waypoint_paths
        )

    def reward(self, sim, agent_id, vehicle: Vehicle):
         delta = self._dist_travelled - self._last_dist_travelled
         self._last_dist_travelled = self._dist_travelled
         return delta

    def perform_action(self, sim, agent_id, vehicle, action):
        max_steer = 45
        throttle, brake, steer = action

        throttle = np.clip(throttle, 0., 1.)
        brake = np.clip(brake, 0., 1.)
        steer = np.clip(steer, -max_steer, max_steer)

        vehicle.apply_throttle(throttle)
        vehicle.apply_brake(brake)
        vehicle.apply_steering(steer)

    def is_done(self, sim, agent_id, vehicle):
        vehicle_pos = vehicle.position

        dist_to_nearest_wp = sim.traffic_sim \
                                .waypoints \
                                .closest_waypoint(vehicle_pos) \
                                .dist_to(vehicle_pos)

        is_offroad = dist_to_nearest_wp > 2.
        is_colliding = sim.agent_did_collide(agent_id)

        if is_offroad:
            self._log.info(f"Agent {agent_id} is off road")

        if is_colliding:
            self._log.info(f"Agent {agent_id} is colliding")

        return is_offroad or is_colliding

    def _compute_additional_dist_travelled(self, waypoint):
        recent_wp = self._collected_wps[-1]
        heading_vec = degrees_to_vec(recent_wp.heading)
        disp_vec = waypoint.pos - recent_wp.pos
        return np.sign(np.dot(heading_vec, disp_vec)) * np.linalg.norm(disp_vec)
