import math
import logging
from collections import namedtuple

import numpy as np

from hiway.utils.math import degrees_to_vec, lerp, trimf
from hiway.vehicle import Vehicle
from hiway.agent import Agent

# from panda3d.core import ShowBoundsEffect


Observation = namedtuple(
    'Observation',
    ['ego_vehicle_state',
     'neighborhood_vehicle_states',
     'top_down_rgb',
     'occupancy_grid_map',
     'waypoint_paths',
     # distance travelled is a signed distance indicating how far along the
     # road the agent has moved. If you move against the direction of the lane
     # the distance reduces. If you move behind the starting position, the
     # distance goes negative.
     'distance_travelled'])


class LaneFollowingAgent(Agent):
    def setup(self, sim, agent_id, vehicle):
        self._log = logging.getLogger(self.__class__.__name__)

        vehicle.init_observation_ogm(64, 64, .25)
        vehicle.init_observation_rgb(256, 256, .1)

        # use the closest waypoint as the target lane id
        self._target_lane_id = sim.traffic_sim \
                                  .waypoints \
                                  .closest_waypoint(vehicle.position) \
                                  .lane_id

        waypoint_paths = sim.traffic_sim.waypoints.waypoint_paths_at(
            vehicle.position, lookahead=1)

        self._collected_wps = [waypoint_paths[0][0]]

    def observation(self, sim, agent_id, vehicle):
        ego_vehicle_state = vehicle.state()
        neighborhood_vehicles = \
            sim.neighborhood_vehicles_around_agent(agent_id, radius=100)
        rgb = vehicle.calc_observation_rgb()
        ogm = vehicle.calc_observation_ogm()

        waypoint_paths = \
            sim.traffic_sim \
               .waypoints \
               .waypoint_paths_at(vehicle.position, lookahead=10)

        for i, path in enumerate(waypoint_paths):
            # color paths to show ordering (red -> blue => right -> left)
            p = (i + 1) / len(waypoint_paths)
            sim.render_waypoint_path(path, color=(1. - p, 0., p, 1.))

        canonical_wp = waypoint_paths[0][0]
        if self._collected_wps[-1].id != canonical_wp.id:
            self._collected_wps.append(canonical_wp)
        sim.render_waypoint_path(self._collected_wps, color=(0., 1., 0., 1.))

        heading_and_disp_vecs = \
            [(degrees_to_vec(wp1.heading), wp2.pos - wp1.pos)
             for wp1, wp2 in zip(self._collected_wps, self._collected_wps[1:])]

        total_travel_dist = sum(
            np.sign(np.dot(heading_vec, disp_vec)) * np.linalg.norm(disp_vec)
            for heading_vec, disp_vec in heading_and_disp_vecs)

        return Observation(ego_vehicle_state=ego_vehicle_state,
                           neighborhood_vehicle_states=neighborhood_vehicles,
                           top_down_rgb=rgb,
                           occupancy_grid_map=ogm,
                           waypoint_paths=waypoint_paths,
                           distance_travelled=total_travel_dist)

    def reward(self, sim, agent_id, vehicle: Vehicle):
        speed_reward_multiplier = 1.0
        centerdness_reward_multiplier = 1.0

        x, y, _ = vehicle.position
        road_network = sim.traffic_sim.road_network

        ego_lane_data = road_network.lane_data_under_point((x, y), radius=2)

        if ego_lane_data is None:
            # the vehicle is too far off the road!!
            return -10

        speed_reward = 0
        if not math.isclose(ego_lane_data.lane_speed, 0):
            speed_reward = trimf(
                np.array([vehicle.speed]),
                a=0,
                b=ego_lane_data.lane_speed * 0.5,
                c=ego_lane_data.lane_speed)[0]

        _u, v = road_network.world_to_lane_coord(ego_lane_data.sumo_lane, (x, y))
        # _u is the distance along the lane
        # v is the signed distance from the lane center (right of center is pos)

        distance = abs(v)
        lane_hwidth = ego_lane_data.sumo_lane.getWidth() * 0.5

        centeredness_reward = trimf(
            np.array([distance]),
            a=0,
            b=0,
            c=lane_hwidth)[0]

        speed_reward *= speed_reward_multiplier
        centeredness_reward *= centerdness_reward_multiplier
        return speed_reward + centeredness_reward

    def _compute_steering_correction(self, sim, vehicle, max_steer):
        wp = sim.traffic_sim \
                .waypoints \
                .closest_waypoint_on_lane(vehicle.position,
                                          self._target_lane_id)

        align_steering_to_lane_heading = wp.relative_heading(vehicle.heading)

        signed_lateral_error = wp.signed_lateral_error(vehicle.position)
        steer_towards_lane_center = \
            -1 * signed_lateral_error / (wp.lane_width * 0.5) * max_steer

        steer_angle_unclipped = \
            lerp(steer_towards_lane_center, align_steering_to_lane_heading, 0.8)
        steer_angle = np.clip(steer_angle_unclipped, -max_steer, max_steer)

        return steer_angle

    def is_done(self, sim, agent_id, vehicle):
        vehicle_pos = vehicle.position

        dist_to_nearest_wp = sim.traffic_sim \
                                .waypoints \
                                .closest_waypoint(vehicle_pos) \
                                .dist_to(vehicle_pos)

        is_offroad = dist_to_nearest_wp > 3.
        is_colliding = sim.agent_did_collide(agent_id)

        if is_offroad:
            self._log.info(f"Agent {agent_id} is off road")

        if is_colliding:
            self._log.info(f"Agent {agent_id} is colliding")

        return is_offroad or is_colliding

    def perform_action(self, sim, agent_id, vehicle, action):
        max_steer = 45
        if action == 'keep_lane':
            self._perform_lane_following(sim, vehicle, max_steer)

        elif action == 'slow_down':
            self._perform_lane_following(sim, vehicle, max_steer)
            vehicle.apply_throttle(0.0)
            vehicle.apply_brake(0.3)

        elif action == 'change_lane_left':
            self._change_lane(sim, vehicle, -1)
            self._perform_lane_following(sim, vehicle, max_steer)

        elif action == 'change_lane_right':
            self._change_lane(sim, vehicle, 1)
            self._perform_lane_following(sim, vehicle, max_steer)

        else:
            raise Exception("Invalid action %s" % action)


    def _perform_lane_following(self, sim, vehicle, max_steer):
        # attempt to stay on the lane center
        steer_angle = \
            self._compute_steering_correction(sim, vehicle, max_steer)
        vehicle.apply_steering(steer_angle)

        s = abs(steer_angle) / max_steer
        vehicle.apply_throttle((1. * (1. - s) ** 2 * 0.99 + 0.01) * 0.3)
        vehicle.apply_brake(np.clip(s ** 0.1, 0, 0.1))

        self._update_target_lane_if_reached_end_of_lane(sim, vehicle)

    def _update_target_lane_if_reached_end_of_lane(self, sim, vehicle):
        # When we reach the end of our target lane, we need to update it
        # to the next lane best lane along the path
        v_pos = vehicle.position
        v_head = vehicle.heading

        paths = sim.traffic_sim \
                   .waypoints \
                   .waypoint_paths_on_lane_at(v_pos,
                                               self._target_lane_id,
                                               lookahead=2)

        candidate_next_wps = []
        for path in paths:
            wps_of_next_lanes_on_path = \
                [wp for wp in path if wp.lane_id != self._target_lane_id]

            if wps_of_next_lanes_on_path == []:
                continue

            next_wp = wps_of_next_lanes_on_path[0]
            candidate_next_wps.append(next_wp)

        if candidate_next_wps == []:
            return

        next_wp = \
            min(candidate_next_wps,
                key=lambda wp: abs(wp.signed_lateral_error(v_pos)) + \
                               abs(wp.relative_heading(v_head)))

        self._target_lane_id = next_wp.lane_id

    def _change_lane(self, sim, vehicle, lane_change_direction):
        paths = sim.traffic_sim.waypoints.waypoint_paths_at(vehicle.position, lookahead=1)

        target_wp = None
        target_lateral_error = None
        for path in paths:
            wp = path[0]
            if wp.lane_id == self._target_lane_id:
                # we are intending to _switch_ lane, don't consider current lane
                continue

            lateral_error = wp.signed_lateral_error(vehicle.position)
            lateral_error *= lane_change_direction

            if lateral_error < 0:
                # this wp is not in the direction we want to change lane towards
                continue

            if target_lateral_error is None \
               or lateral_error < target_lateral_error:
                target_wp = wp
                target_lateral_error = lateral_error

        if target_wp:
            self._target_lane_id = target_wp.lane_id
