import numpy
import os
import sys
import logging
import math
import time
import subprocess
import random

from collections import namedtuple


if 'SUMO_HOME' not in os.environ:
    sys.exit('SUMO_HOME not set')

SUMO = os.environ['SUMO_HOME']
sys.path.append(os.path.join(SUMO, 'tools'))

import traci
import traci.constants as tc
import sumolib

from .sumo_road_network import SumoRoadNetwork
from .waypoints import Waypoints


TrafficSimVehicle = namedtuple(
    'TrafficSimVehicle',
    [
        'vehicle_id',
        'pos',
        'angle',
        'speed',
    ])


class SumoTrafficSimulation():
    def __init__(self, scenario, headless=False, time_resolution=0.1, debug=True):
        """
        Args:
            net_file: path to sumo .net.xml file
            headless: (default: False)
              False to run with `sumo-gui`. True to run with `sumo`
            time_resolution: (default: 0.016)
              The SUMO simulation is descretized into steps of `time_resolution` seconds
              WARNING:
                Since our interface(TRACI) to SUMO is delayed by one simulation step, setting
                a higher time resolution may lead to unexpected artifacts.
        """
        self._log = logging.getLogger(self.__class__.__name__)

        self._scenario = scenario
        self._time_resolution = time_resolution
        self._headless = headless
        self._cumulative_sim_seconds = 0
        self._non_sumo_vehicle_ids = set()
        self._is_setup = False
        self._road_network = SumoRoadNetwork.from_file(scenario.net_filepath)
        self._waypoints = Waypoints(
            self._road_network, spacing=1., debug=debug)
        self._last_trigger_time = -1000000
        self._num_dynamic_routes_added = 0
        self._traci_conn = None

        self._log.debug("State before traci_conn %s" % self)
        self._initialize_traci_conn()

    @property
    def road_network(self):
        return self._road_network

    @property
    def waypoints(self):
        return self._waypoints

    def _initialize_traci_conn(self):
        sumo_port = sumolib.miscutils.getFreeSocketPort()
        sumo_binary = 'sumo' if self._headless else 'sumo-gui'
        sumo_cmd = [
            os.path.join(SUMO, 'bin', sumo_binary),
            '--remote-port=%s' % sumo_port,

            # SUMO will not start without a net or sim cfg file
            '--net-file=%s' % self._scenario.net_filepath,

            # We need these options to be reset simulation state.
            '--start',
            '--quit-on-end',
            '--log=%s' % self._scenario.sumo_log_dir,
        ]

        self._log.debug("Starting sumo process:\n\t %s", sumo_cmd)
        sumo_proc = subprocess.Popen(sumo_cmd, preexec_fn=os.setsid, stdout=sys.stdout)
        time.sleep(0.1) # give SUMO time to start
        self._traci_conn = traci.connect(sumo_port, numRetries=100, proc=sumo_proc)
        self._log.debug("Finished starting sumo process")

    def __repr__(self):
        return f"""SumoTrafficSim(
  _scenario={repr(self._scenario)},
  _time_resolution={self._time_resolution},
  _headless={self._headless},
  _cumulative_sim_seconds={self._cumulative_sim_seconds},
  _non_sumo_vehicle_ids={self._non_sumo_vehicle_ids},
  _is_setup={self._is_setup},
  _road_network={repr(self._road_network)},
  _last_trigger_time={self._last_trigger_time},
  _num_dynamic_routes_added={self._num_dynamic_routes_added},
  _traci_conn={repr(self._traci_conn)}
)"""

    def __str__(self):
        return repr(self)

    def setup(self):
        self._log.debug("Setting up SumoTrafficSim %s" % self)
        assert not self._is_setup, "Can't setup twice, %s, see teardown()" % self._is_setup
        assert self._traci_conn is not None, "No active traci conn"

        load_params = [
            '--net-file=%s' % self._scenario.net_filepath,
            '--lanechange.duration=3.0', # Smooth lane changes
            '--step-length=%f' % self._time_resolution,
            '--start',
            '--begin=0',  # start simulation at time=0
            '--end=3153600',  # keep the simulation running for a year
            '--quit-on-end',
            '--no-step-log',
            '--no-warnings=1',
            '--error-log=%s' % self._scenario.sumo_log_dir,
            '--log=%s' % self._scenario.sumo_log_dir,
        ]

        self._traci_conn.load(load_params)

        self._traci_conn.simulation.subscribe(
            [tc.VAR_DEPARTED_VEHICLES_IDS, tc.VAR_ARRIVED_VEHICLES_IDS])

        # place social vehicles randomly throughout the map on start
        self._compute_random_social_vehicles(
            n=self._scenario.random_social_vehicle_count)

        self._is_setup = True

    def teardown(self):
        self._log.debug("Tearing down SUMO traffic sim %s" % self)
        if not self._is_setup:
            self._log.warn("Nothing to teardown")
            return

        assert self._is_setup
        self._cumulative_sim_seconds = 0
        self._non_sumo_vehicle_ids = set()
        self._is_setup = False
        self._last_trigger_time = -1000000
        self._num_dynamic_routes_added = 0

    def step(self, dt, managed_vehicles):
        """
        Args:
            dt: time (in seconds) to simulate during this simulation step
            managed_vehicles: dict of {vehicle_id: (x, y, angle)}
                !! The vehicle state should represent the state of the
                !! vehicles at the start of the current simulation step
        Returns:
            list[TrafficSimVehicle] representing state of all SUMO-managed vehicles
            in the traffic simulation
        """
        assert self._is_setup, 'You must `setup` before you can `step`'

        # !! It's important that we sync managed vehicles before we step the
        # SUMO simulation because the `managed_vehicles` represents the state
        # of these vehicles at start of frame.
        # If we were to sync after we step SUMO, sumo would see these
        # managed vehicles with a 1 step delay.
        self._sync_managed_vehicles_with_sumo(managed_vehicles)
        self._compute_social_vehicle_triggers(managed_vehicles)

        # we tell SUMO to step through dt more seconds of the simulation
        self._cumulative_sim_seconds += dt
        self._traci_conn.simulationStep(self._cumulative_sim_seconds)

        return self._compute_traffic_vehicles()

    def _sync_managed_vehicles_with_sumo(self, managed_vehicles):
        managed_vehicles_that_have_left_sim = \
            (v for v
             in self._non_sumo_vehicle_ids
             if v not in managed_vehicles)

        for vehicle_id in managed_vehicles_that_have_left_sim:
            self._log.debug('Non SUMO vehicle %s left simulation', vehicle_id)
            self._non_sumo_vehicle_ids.remove(vehicle_id)
            self._traci_conn.remove(vehicle_id)

        managed_vehicles_that_have_just_joined_sim = \
            (v for v
             in managed_vehicles
             if v not in self._non_sumo_vehicle_ids)

        for vehicle_id in managed_vehicles_that_have_just_joined_sim:
            assert type(vehicle_id) == str

            self._log.debug('Non SUMO vehicle %s joined simulation', vehicle_id)
            self._non_sumo_vehicle_ids.add(vehicle_id)
            self._traci_conn.vehicle.add(
                vehID=vehicle_id,
                routeID=''  # we don't care which route this vehicle is on
            )

            # Configure this non-SUMO managed vehicle
            self._traci_conn.vehicle.setColor(vehicle_id, (255, 0, 0))  # red in sumo-gui

            # these configuration options helps sumo avoid doing extra work for
            # these managed vehicles
            self._traci_conn.vehicle.setTau(vehicle_id, 0.0)
            self._traci_conn.vehicle.setDecel(vehicle_id, 0.0001)  # XXX: 0 causes a SUMO assert
            self._traci_conn.vehicle.setApparentDecel(vehicle_id, 0.0)
            self._traci_conn.vehicle.setEmergencyDecel(vehicle_id, 0.0)

        # update the state of all current managed vehicles
        for (vehicle_id, vehicle_state) in managed_vehicles.items():
            pos, engine_heading = vehicle_state
            x, y, _ = pos

            sumo_angle = -engine_heading + 90
            self._traci_conn.vehicle.moveToXY(
                vehID=vehicle_id,
                edgeID='',  # let sumo choose the edge
                lane=-1,  # let sumo choose the lane
                x=x,
                y=y,
                angle=sumo_angle,  # only used for visualizing in sumo-gui
                keepRoute=2  # gives vehicle freedom to move off road
            )

    def _compute_traffic_vehicles(self):
        sub_results = self._traci_conn \
                          .simulation \
                          .getSubscriptionResults()

        newly_departed_sumo_traffic = \
            (vehicle_id for vehicle_id
             in sub_results[tc.VAR_DEPARTED_VEHICLES_IDS]
             if vehicle_id not in self._non_sumo_vehicle_ids)

        for vehicle_id in newly_departed_sumo_traffic:
            self._log.debug('SUMO vehicle %s entered simulation', vehicle_id)
            self._traci_conn.vehicle.subscribe(
                vehicle_id,
                [tc.VAR_POSITION, tc.VAR_ANGLE, tc.VAR_SPEED,
                 tc.VAR_ROUTE_INDEX, tc.VAR_EDGES, tc.VAR_ROAD_ID])

        exited_sumo_traffic = \
            (vehicle_id for vehicle_id
             in sub_results[tc.VAR_ARRIVED_VEHICLES_IDS]
             if vehicle_id not in self._non_sumo_vehicle_ids)

        for vehicle_id in exited_sumo_traffic:
            self._log.debug('SUMO vehicle %s left simulation', vehicle_id)

        sumo_vehicle_state = \
            self._traci_conn.vehicle.getAllSubscriptionResults()
        traffic_vehicles = []
        for sumo_id, sumo_vehicle in sumo_vehicle_state.items():
            hiway_position = sumo_vehicle[tc.VAR_POSITION]
            hiway_angle = -sumo_vehicle[tc.VAR_ANGLE]
            hiway_speed = sumo_vehicle[tc.VAR_SPEED] * 3.6  # m/s -> km/h
            route_index = sumo_vehicle[tc.VAR_ROUTE_INDEX]
            route_edges = sumo_vehicle[tc.VAR_EDGES]
            current_road_id = sumo_vehicle[tc.VAR_ROAD_ID]

            if route_index == len(route_edges) - 1:
                if current_road_id == '':
                    current_road_id = route_edges[-1]

                # this vehicle needs to be re-routed since it's nearing it's
                # destination edge.
                self._set_new_route_for_vehicle_id(sumo_id, current_road_id)

            traffic_vehicles.append(
                TrafficSimVehicle(
                    vehicle_id=sumo_id,
                    pos=hiway_position,
                    angle=hiway_angle,
                    speed=hiway_speed))

        return traffic_vehicles

    def best_lanes(self, vid):
        if vid not in self._non_sumo_vehicle_ids:
            self._log.warn("No sumo vehicle with this vehicle id")
            return None
        return self._traci_conn.vehicle.getBestLanes(vid)

    def _compute_social_vehicle_triggers(self, managed_vehicles):
        trigger_nodes = self._road_network.road_nodes_with_triggers()
        time_since_last = self._cumulative_sim_seconds - self._last_trigger_time
        for (trigger_node, spawn_nodes) in trigger_nodes:
            for v_id, v_pose in managed_vehicles.items():
                pos, _angle = v_pose
                x, y, _ = pos
                t_x, t_y = trigger_node.getCoord()
                d = math.sqrt((t_x - x) ** 2 + (t_y - y) ** 2)
                if d < 150 and time_since_last > 5:
                    self._last_trigger_time = self._cumulative_sim_seconds
                    for s in spawn_nodes:
                        self._emit_vehicle(s)

    def _compute_random_social_vehicles(self, n):
        spawn_nodes = self._road_network.graph.getNodes()
        spawn_nodes = numpy.random.choice(spawn_nodes, n, replace=True)
        for node in spawn_nodes:
            self._emit_vehicle(node)

    def _unique_route_id(self):
        route_id = "hiway_route_%s" % self._num_dynamic_routes_added
        self._num_dynamic_routes_added += 1
        return route_id

    def _set_new_route_for_vehicle_id(self, vehicle_id, starting_edge_id):
        starting_edge = self._road_network.graph.getEdge(starting_edge_id)
        route = self._road_network.random_route_starting_at_edge(starting_edge)
        self._log.debug(f"Re-routing {vehicle_id} to {repr(route)}")
        self._traci_conn.vehicle.setRoute(vehicle_id, route)

    def _emit_vehicle(self, node):
        route_id = self._unique_route_id()
        vehicle_id = "sv_started_on_%s" % route_id

        route = self._road_network.random_route_starting_at_node(node)
        spawn_edge = self._road_network.graph.getEdge(route[0])
        spawn_lane_idx = random.randint(0, len(spawn_edge.getLanes()) - 1)

        spacing = 1
        descretized_pos = int(random.random() * spawn_edge.getLength() / spacing) * spacing

        self._traci_conn.route.add(route_id, route)
        self._traci_conn.vehicle.add(
            vehicle_id,
            route_id,
            departPos=descretized_pos,
            departLane=spawn_lane_idx)
