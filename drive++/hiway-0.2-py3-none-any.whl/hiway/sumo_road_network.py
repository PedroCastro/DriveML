import sys
import os
import logging
import re
import random

from collections import namedtuple

import numpy as np

from panda3d.core import (
    CS_zup_right,
    Point3D,
)

from panda3d.egg import (
    EggVertexPool,
    EggVertex,
    EggData,
    EggPolygon
)

from shapely.geometry import (
    Polygon,
    LineString,
    CAP_STYLE,
    JOIN_STYLE,
)

from shapely.ops import polygonize

if 'SUMO_HOME' not in os.environ:
    sys.exit('SUMO_HOME not set')

SUMO = os.environ['SUMO_HOME']
sys.path.append(os.path.join(SUMO, 'tools'))

import sumolib
from sumolib.net.lane import Lane
from .utils.math import vec_to_degrees


LaneData = namedtuple("LaneData", ["sumo_lane", "lane_speed"])

class SumoRoadNetwork:
    def __init__(self, graph):
        self._log = logging.getLogger(self.__class__.__name__)
        self._graph = graph

    @classmethod
    def from_file(cls, net_file):
        G = sumolib.net.readNet(net_file)
        return SumoRoadNetwork(G)

    @property
    def graph(self):
        return self._graph

    def _compute_road_polygons(self, scale):
        lines = []
        for edge in self._graph.getEdges():
            for lane in edge.getLanes():
                lane_hwidth = lane.getWidth() * 0.5
                lane_line = lane.getShape()
                line = LineString(lane_line).buffer(
                    lane_hwidth * 0.95,  # Scale down to see spacing
                    cap_style=CAP_STYLE.square,
                    join_style=JOIN_STYLE.mitre)

                lines.append(line)

        polys = list(polygonize(lines))

        for node in self._graph.getNodes():
            line = node.getShape()
            if len(line) <= 2:
                self._log.debug(
                    'Skipping {}-type node with <= 2 vertices'
                    .format(node.getType()))
                continue

            polys.append(Polygon(line))

        return polys

    def _make_egg_from_polys(self, polygons):
        egg = EggData()
        egg.set_coordinate_system(CS_zup_right)

        vertex_pool = EggVertexPool('road_network_vpool')
        for poly in polygons:
            egg_poly = EggPolygon()

            # shapely gives us points in the wrong direction,
            # we reverse so that geometry is visible
            for x, y in reversed(poly.exterior.coords):
                new_egg_vertex = EggVertex()
                new_egg_vertex.set_pos(Point3D(x, y, 0.))

                # only add this new vertex to the pool if there
                # doesn't exist one that matches this one
                egg_vertex = vertex_pool.create_unique_vertex(new_egg_vertex)
                egg_poly.add_vertex(egg_vertex)

            egg_poly.triangulate_into(egg, convex_also=True)

        egg.add_child(vertex_pool)
        return egg

    def build_egg(self, scale=1) -> EggData:
        polys = self._compute_road_polygons(scale)
        return self._make_egg_from_polys(polys)

    def lane_by_id(self, lane_id):
        return self._graph.getLane(lane_id)

    def lane_vector_at_offset(self, lane: Lane, offset: float) -> np.ndarray:
        """
        Computes the lane direction vector at the given offset into the road
        """
        lane_shape = lane.getShape(True)
        accum_dist = 0
        for p1, p2 in zip(lane_shape, lane_shape[1:]):
            accum_dist += sumolib.geomhelper.distance(p1, p2)

            if accum_dist >= offset:
                # our position on the lane is somewhere between p1 and p2
                # now calculate the vector made by these two points
                return np.array(p2) - np.array(p1)

        raise ValueError(
            "Offset goes out farther than end of lane. %s, %s" % (offset, lane))

    def snap_to_lane(self, point, radius=10):
        """
        Args:
          point: (x, y) find a valid position on a lane near this coordinate
          radius: max distance to search around point for a lane

        Returns
          None: if no lane is within radius of the point
          (np.array([x, y]), angle): position and angle on the nearest lane
        """
        lane = self.nearest_lane(point, radius=radius)

        if not lane:
            return None

        lane_offset = self.offset_into_lane(lane, point)
        lane_center_at_offset = self.world_coord_from_offset(lane, lane_offset)

        lane_vector = self.lane_vector_at_offset(lane, lane_offset)
        angle = vec_to_degrees(lane_vector)
        return lane_center_at_offset, angle

    def lane_data_under_point(self, point, radius=10) -> LaneData:
        lane = self.nearest_lane(point, radius=radius)

        if lane is None:
            return None

        return self.lane_data_for_lane(lane)

    def lane_data_for_lane(self, lane):
        lane_speed = lane.getSpeed() * 3.6  # m/s -> km/h
        return LaneData(sumo_lane=lane, lane_speed=lane_speed)

    def nearest_lane(self, point, radius=10) -> Lane:
        """
        Args:
          point: (x, y) find the nearest lane to this coordinate
          radius: max distance to search around point for a lane
        """

        x, y = point
        candidate_lanes = self._graph.getNeighboringLanes(
            x, y, r=radius, includeJunctions=True, allowFallback=False)

        if len(candidate_lanes) == 0:
            return None

        candidate_lanes.sort(key=lambda lane_dist_tup: lane_dist_tup[1])

        # we've checked that we have at least one
        return candidate_lanes[0][0]

    def lane_center_at_point(self, lane: Lane, point) -> np.ndarray:
        lane_offset = self.offset_into_lane(lane, point)
        lane_center_at_offset = self.world_coord_from_offset(lane, lane_offset)
        return lane_center_at_offset

    def world_to_lane_coord(self, lane: Lane, point) -> np.ndarray:
        """
        Maps a world coordinate to a lane local coordinate

        Args:
          lane: sumo lane object
          point: (x, y) world space coordinate

        Returns:
          np.array([u, v]) where
              u is meters into the lane,
              v is signed distance from center (right of center is negative)
        """

        u = self.offset_into_lane(lane, point)
        lane_vector = self.lane_vector_at_offset(lane, u)
        lane_normal = np.array([-lane_vector[1], lane_vector[0]])

        lane_center_at_u = self.world_coord_from_offset(lane, u)
        offcenter_vector = np.array(point) - lane_center_at_u

        v_sign = np.sign(np.dot(offcenter_vector, lane_normal))
        v = np.linalg.norm(offcenter_vector) * v_sign

        return np.array([u, v])

    def offset_into_lane(self, lane, point):
        """
        Calculate how far (in meters) into the lane the given point is

        Args:
          point: (x, y) find the position on the lane to this coordinate
          lane: sumo network lane

        Returns:
          offset_into_lane: meters from start of lane
        """
        lane_shape = lane.getShape(True)

        offset_into_lane = \
            sumolib.geomhelper \
                   .polygonOffsetWithMinimumDistanceToPoint(point, lane_shape, perpendicular=True)

        return offset_into_lane

    def world_coord_from_offset(self, lane: Lane, offset) -> np.ndarray:
        """
        Convert offset into lane to world coordinates

        Args:
          offset: meters into the lane
          lane: sumo network lane

        Returns:
          np.array([x, y]): coordinates in world space
        """
        lane_shape = lane.getShape(True)

        position_on_lane = \
            sumolib.geomhelper \
                   .positionAtShapeOffset(lane_shape, offset)

        return np.array(position_on_lane)

    def road_nodes_with_triggers(self):
        """
        Scan the road network for any nodes with ID's that match the form:

            .*=trigger[<spawn_node_id_1>@<spawn_node_id_2>@...]

        A node with an ID with this pattern signals to the simulator that
        when an agent comes within some radius of this node, we should spawn
        social vehicles at the listed spawn nodes

        Returns:
          [(trigger_node, [spawn_nodes])]: list of all trigger nodes and their
                                           spawn nodes in the network.
        """
        nodes = self._graph.getNodes()
        nodes_with_triggers = []
        for node in nodes:
            # example node id with trigger:
            #  'gneJ2=trigger[source1@source2@source3]'
            matches = re.match(r'.*=trigger\[(.*)\]', node.getID())
            if matches is None:
                continue

            spawn_node_ids =  matches.group(1).split('@')

            for spawn_node_id in spawn_node_ids:
                # verify that these spawn nodes exist
                assert self._graph.hasNode(spawn_node_id)

            spawn_nodes = [self._graph.getNode(s) for s in spawn_node_ids]
            nodes_with_triggers.append((node, spawn_nodes))

        return nodes_with_triggers

    def random_route_starting_at_edge(self, edge, max_route_len=5):
        route = []
        curr_edge = edge
        while len(route) < max_route_len:
            route.append(curr_edge.getID())

            next_edges = list(curr_edge.getOutgoing().keys())
            if not next_edges:
                break

            curr_edge = random.choice(next_edges)

        return route

    def random_route_starting_at_node(self, node, max_route_len=5):
        route = []

        if not node.getOutgoing():
            # this node is terminating
            return route

        edge = random.choice(node.getOutgoing())
        return self.random_route_starting_at_edge(edge, max_route_len)

    def shortest_route(self, from_edge, to_edge):
        edges, cost = self._graph.getShortestPath(from_edge, to_edge)
        return edges
