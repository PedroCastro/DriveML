class RenderTags:
    # Exclude some node path from the occupancy grid map
    EXCLUDE_FROM_OCCUPANCY = 'EXCLUDE_FROM_OCCUPANCY'
    EXCLUDE_FROM_RGBD = 'EXCLUDE_FROM_RGBD'

class Tags:
    VEHICLE_COLLISION = 'VEHICLE_COLLISION'
