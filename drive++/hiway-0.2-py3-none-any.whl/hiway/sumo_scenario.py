import os
import sys

from hiway.sumo_road_network import SumoRoadNetwork


class SumoScenario():
    """
    The purpose of the SumoScenario is to provide an aggregate of all
    code/configuration/assets that is specialized to a scenario using SUMO.

    # SumoScenario is `pickle`able, this is important for use with frameworks like Ray/rllib
    >>> import pickle
    >>> scenario = SumoScenario("scenarios/loop")
    >>> unpickled_scenario = pickle.loads(pickle.dumps(scenario))
    >>> scenario.root_filepath == unpickled_scenario.root_filepath
    True
    """

    def __init__(self,
                 scenario_root: str,
                 log_dir: str = "./_run_logs",
                 random_social_vehicle_count: int = 0):
        """
        scenario_root: the scenario asset folder ie. './scenarios/trigger'
        random_social_vehicle_count: number of social vehicles to position randomly on the map at start
        """
        self._root = scenario_root
        self._log_dir = os.path.abspath(log_dir)
        self._random_social_vehicle_count = random_social_vehicle_count

        self._validate_assets_exist()

        self._random_social_vehicle_count = random_social_vehicle_count

    def __repr__(self):
        return f"""SumoScenario(
  _root={self._root},
  _random_social_vehicle_count={self._random_social_vehicle_count}
)"""

    @property
    def root_filepath(self):
        return self._root

    @property
    def net_filepath(self):
        return '%s/map.net.xml' % self._root

    @property
    def map_egg_filepath(self):
        return '%s/map.egg' % self._root

    @property
    def sumo_log_dir(self):
        return os.path.join(self._log_dir, "sumo")

    @property
    def road_network(self):
        return self._road_network

    @property
    def random_social_vehicle_count(self):
        return self._random_social_vehicle_count

    def _validate_assets_exist(self):
        for f in [self.net_filepath, self.map_egg_filepath]:
            assert os.path.exists(f), '{} is missing'.format(f)

        if not os.path.exists(self._log_dir):
            os.makedirs(self._log_dir)

        # make sure we can load the sumo network
        net = SumoRoadNetwork.from_file(self.net_filepath)
        assert net is not None
