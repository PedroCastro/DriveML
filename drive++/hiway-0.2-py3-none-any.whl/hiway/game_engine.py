import math
import os
from collections import defaultdict, OrderedDict

import logging

# ShowBase loads `globalClock` and `base` in global namespace
from direct.showbase.ShowBase import ShowBase

from panda3d.core import (
    ClockObject,
    loadPrcFileData
)

from panda3d.core import BoundingBox as P3DBoundingBox


# disable vsync otherwise we are limited to refresh-rate of screen
loadPrcFileData('', 'sync-video false')
loadPrcFileData('', 'model-path %s' % os.getcwd())

# https://www.panda3d.org/manual/?title=Multithreaded_Render_Pipeline
# loadPrcFileData('', 'threading-model Cull/Draw')

# have makeTextureBuffer create a visible window
# loadPrcFileData('', 'show-buffers true')


class GameEngine(ShowBase):
    def __init__(self, headless=False, timestep_sec=0.01):
        window_type = 'offscreen' if headless else 'onscreen'
        ShowBase.__init__(self, windowType=window_type)

        # global clock always proceeds by a fixed dt on each tick
        self.taskMgr.clock.set_mode(ClockObject.M_non_real_time)
        self.taskMgr.clock.set_dt(timestep_sec)

        self._log = logging.getLogger(self.__class__.__name__)

        self.setBackgroundColor(0, 0, 0, 1)

        # displayed framerate is misleading since we
        # are not using a realtime clock
        self.setFrameRateMeter(False)

        self._sims = OrderedDict()

    def add_simulation(self, sim_id, sim):
        self._sims[sim_id] = sim

    def step(self, action_msg):
        try:
            return self._step(action_msg)
        except KeyboardInterrupt:
            # ensure we clean-up if the user exits the simulation
            self._log.info('Simulation was interrupted by the user')
            self.teardown()
            raise # re-raise the KeyboardInterrupt
        except Exception as e:
            self._log.error(
                'Simulation crashed with exception.'
                'Attempting to cleanly shutdown.')
            self._log.exception(e)
            self.teardown()
            raise # re-raise

    def _step(self, action_msg):
        """Steps through the simulation while applying the given agent actions.
        Returns the observations, rewards, and done signals.
        """

        # Due to a limitation of our traffic simulator(SUMO) interface(TRACI),
        # We can only observe traffic state of the previous simulation step.
        #
        # To compensate for this, we:
        #
        # 1. step the traffic simulation
        # 2. calculate reward/observations
        # 3. apply agent actions
        # 4. step the physics simulation
        #
        # In this way, observations and reward are computed with data that is
        # consistently with one step of latencey and the agent will observe
        # consistent data.
        dt = self.taskMgr.clock.get_dt()

        # 1. step traffic simulation
        for sim in self._sims.values():
            sim.step_traffic(dt)

        # render and the other panda internal stuff.
        # It's important we call this here because we
        # rely on the the render pipeline for some of
        # the observation/reward calculations

        # self.taskMgr.step() does some extra signal handling before calling poll,
        # the signal handling has a non-negligible overhead, I don't think we need it since it's even
        # behind an optional import, lets see if we can avoid doing it.
        #
        # If we run into weird error cases, we can revert back to calling self.taskMgr.step()
        self.taskMgr.mgr.poll()

        for sim_id, sim in self._sims.items():
            sim.after_frame()

        # 2. perform agent action
        agent_dones = defaultdict(dict)
        for sim_id, agent_actions in action_msg.items():
            assert sim_id in self._sims, 'No sim registered under id: %s' % sim_id
            self._sims[sim_id].perform_agent_actions(agent_actions)

            for agent_id, _ in agent_actions.items():
                agent_dones[sim_id][agent_id] = \
                    self._sims[sim_id].is_agent_done(agent_id)

        # 3. calculate observation and reward
        observations = self._calc_observations()
        rewards = self._calc_rewards()

        # 4. step the physics simulation
        for sim in self._sims.values():
            sim.step_physics(dt)

        if len(self._sims) == 1:
            sim = list(self._sims.values())[0]
            self._stare_at_np(sim.vehicles_np)

        return observations, rewards, agent_dones

    def reset(self):
        self.teardown()
        self.setup()
        return self._calc_observations()

    def _calc_rewards(self):
        return {sim_id: sim.reward() for sim_id, sim in self._sims.items()}

    def _calc_observations(self):
        return {sim_id: sim.observation() for sim_id, sim in self._sims.items()}

    def setup(self):
        for i, sim_id in enumerate(self._sims):
            sim = self._sims[sim_id]
            sim_np = self.render.attachNewNode('sim-%s' % sim_id)
            sim.np.reparentTo(sim_np)

            # We must offset the sim before calling setup
            # this restriction is put in place because of the way
            # the bullet integration works. The bullet integration
            # takes over positioning of the node.
            #
            # Once a bullet node is attached to the bullet world,
            # the nodes *current* transform is applied, no subsequent
            # transform will be respected by the bullet integration
            sim_w, sim_h = sim.dimension_hints
            cells_per_side = math.ceil(math.sqrt(len(self._sims)))
            x_offset = (i // cells_per_side) * sim_w
            y_offset = (i % cells_per_side) * sim_h
            sim.np.setPos(x_offset, y_offset, 0.)
            sim.setup()

        self._setup_camera()

    def teardown(self):
        for sim in self._sims.values():
            sim.teardown()

    def destroy(self):
        self.teardown()
        super().destroy()

    def _setup_camera(self):
        if len(self._sims) == 0:
            # in case no simulations were set, just look down
            self.cam.lookAt(0, 0, 0)
            self.cam.setPos(0, 0, 100)
            return

        # position the camera to look at the _first simulation added_
        # the user can zoom out to look at the rest of the simulations
        sim = list(self._sims.values())[0]

        bounds = sim.np.getTightBounds()
        bounds = P3DBoundingBox(*bounds)
        center = bounds.getApproxCenter()

        # TODO: Handle Z component
        self.cam.lookAt(sim.np, center)
        self.cam.setPos(center[0], center[1], 300)
        self.cam.setHpr(0, -90, 0)

    def _stare_at_np(self, np, h_offset=100):
        bounds = np.getBounds()
        radius = min(bounds.getRadius(), 10000000)
        center = bounds.getCenter()
        self.cam.setPos(center[0], center[1], radius + h_offset)
        self.cam.lookAt(center)
