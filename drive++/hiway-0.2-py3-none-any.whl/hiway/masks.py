class RenderMasks:
    OCCUPANCY_HIDE = 0x01
    RGB_HIDE = 0x02
