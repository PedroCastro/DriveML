class Agent:
    def __init__(self, debug=False):
        self.debug = debug

    def setup(self, sim, agent_id, vehicle):
        pass

    def teardown(self, sim, agent_id, vehicle):
        pass

    def observation(self, sim, agent_id, vehicle):
        raise NotImplementedError()

    def reward(self, sim, agent_id, vehicle):
        raise NotImplementedError()

    def perform_action(self, sim, agent_id, vehicle, action):
        raise NotImplementedError()

    def is_done(self, sim, agent_id, vehicle):
        return False
