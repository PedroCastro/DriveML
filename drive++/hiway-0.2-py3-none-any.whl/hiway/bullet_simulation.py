from collections import namedtuple
import logging

import numpy

from panda3d.core import (
    NodePath,
    Vec3,
    Vec4,
    BitMask32,
    LineSegs,
    AmbientLight,
    DirectionalLight,
)

from panda3d.bullet import (
    BulletDebugNode,
    BulletWorld,
    BulletPlaneShape,
    BulletRigidBodyNode,
    BulletTriangleMeshShape,
    BulletTriangleMesh
)

from .vehicle import Vehicle
from .social_vehicle import SocialVehicle
from .tags import RenderTags, Tags
from .agent import Agent
from .utils.math import degrees_to_vec, squared_dist


SimulationObservation = namedtuple(
    'SimulationObservation', ['agent_observations'])

SimulationReward = namedtuple(
    'SimulationReward', ['agent_rewards'])


class BulletSimulation():
    def __init__(
            self,
            sim_setter_upper,
            traffic_sim,
            dimension_hints=(0, 0),
            debug=False):
        self._log = logging.getLogger(self.__class__.__name__)

        self._traffic_sim = traffic_sim
        self._sim_setter_upper = sim_setter_upper
        self._dimension_hints = dimension_hints
        self._debug = debug

        self._root_np = NodePath('bullet-sim')
        self._frame_debug_np = None  # this node is cleared after every frame
        self._vehicle_np = None
        self._traffic_np = None
        self._world = None
        self._agents = {}
        self._agent_collisions = {}
        self._social_vehicles = {}

    def setup(self):
        self._traffic_sim.setup()

        self._world = BulletWorld()
        self._world.setGravity(Vec3(0, 0, -9.81))

        debug_np = self._root_np.attachNewNode(BulletDebugNode('debug'))
        debug_np.setTag(RenderTags.EXCLUDE_FROM_RGBD, str(True))
        debug_np.setTag(RenderTags.EXCLUDE_FROM_OCCUPANCY, str(True))
        if self._debug:
            debug_np.show()
        self._world.setDebugNode(debug_np.node())

        ground_np = self._root_np.attachNewNode(BulletRigidBodyNode('ground'))
        ground_np.setPos(0, 0, 0)
        ground_np.setCollideMask(BitMask32.allOn())
        ground_np.node().addShape(BulletPlaneShape(Vec3(0, 0, 1), 0))
        self._world.attach(ground_np.node())
        self._world.setContactAddedCallback(self._on_collision)

        self._vehicles_np = self._root_np.attachNewNode('vehicles')
        self._traffic_np = self._root_np.attachNewNode('traffic')
        self._clear_frame_debug_np()

        self._setup_lighting()

        self._sim_setter_upper(self)

    def teardown(self):
        if self._world is not None:
            self._world.clearContactAddedCallback()
        self._traffic_sim.teardown()
        self._root_np.clearLight()
        self._root_np.removeNode()
        self._root_np = NodePath('bullet-sim')
        self._vehicles_np = None
        self._frame_debug_np = None
        self._world = None

        for agent_id, agent_tup in self._agents.items():
            agent, vehicle = agent_tup
            agent.teardown(self, agent_id, vehicle)
            vehicle.teardown()

        self._agents = {}
        self._agent_collisions = {}
        self._social_vehicles = {}

    @property
    def np(self):
        assert self._root_np is not None
        return self._root_np

    @property
    def vehicles_np(self):
        assert self._vehicles_np is not None
        return self._vehicles_np

    @property
    def dimension_hints(self):
        return self._dimension_hints

    @property
    def traffic_sim(self):
        return self._traffic_sim

    def render_waypoint_path(self, path, h_offset=1., color=(1., 0., 1., 1.)):
        if path == []:
            self._log.warn("Attempted to render empty path")
            return

        r = 1.
        for waypoint in path:
            x1, y1 = waypoint.pos
            x2, y2 = waypoint.pos + degrees_to_vec(waypoint.heading) * r

            lines = LineSegs()
            lines.setColor(*color)
            lines.setThickness(5.)
            lines.moveTo(x1, y1, h_offset)
            lines.draw_to(x2, y2, h_offset)

            waypoint_np = NodePath(lines.create())
            waypoint_np.reparentTo(self._frame_debug_np)

    def after_frame(self):
        self._clear_frame_debug_np()

    def _clear_frame_debug_np(self):
        """Clears the 'frame debug node'"""
        if self._frame_debug_np is not None:
            self._frame_debug_np.removeNode()

        self._frame_debug_np = self._root_np.attachNewNode('frame_debug')

        # self._frame_debug_np = self._root_np.attachNewNode('frame_debug')
        self._frame_debug_np.setTag(
            RenderTags.EXCLUDE_FROM_RGBD, str(True))
        self._frame_debug_np.setTag(
            RenderTags.EXCLUDE_FROM_OCCUPANCY, str(True))

    def step_traffic(self, dt):
        # we must calculate the state of the non-traffic vehicles *before* we
        # step the world so that the traffic simulation and the Bullet
        # simulation remain in lock step.
        # (otherwise, traffic sim will see state that is  one frame ahead)
        agent_vehicle_states = {}
        for agent_id, agent_tup in self._agents.items():
            _agent, vehicle = agent_tup
            agent_vehicle_states[agent_id] = (vehicle.position, vehicle.heading)

        social_vehicle_state = self._traffic_sim.step(dt, agent_vehicle_states)

        previous_vehicle_ids = set(self._social_vehicles.keys())
        current_vehicle_ids = {v.vehicle_id for v in social_vehicle_state}

        exited_vehicles = previous_vehicle_ids - current_vehicle_ids
        new_vehicles = current_vehicle_ids - previous_vehicle_ids

        for v_id in exited_vehicles:
            social_vehicle = self._social_vehicles[v_id]
            self._world.remove(social_vehicle.np.node())
            social_vehicle.teardown()
            del self._social_vehicles[v_id]

        for v_id in new_vehicles:
            social_vehicle = SocialVehicle(v_id)
            self._social_vehicles[v_id] = social_vehicle
            social_vehicle.np.reparentTo(self._root_np)
            self._world.attach(social_vehicle.np.node())

        for v in social_vehicle_state:
            assert v.vehicle_id in self._social_vehicles
            self._social_vehicles[v.vehicle_id].update_from_traffic_sim(v)

        # update agent's vehicle lap count
        for agent_id, agent_tup in self._agents.items():
            _, vehicle = agent_tup

    def step_physics(self, dt):
        self._world.doPhysics(dt, 10000, 0.01)

    def neighborhood_vehicles_around_agent(self, agent_id, radius=100):
        # Object list of nearby social vehicles
        vehicles = []
        for _, vehicle in self._social_vehicles.items():
            vehicles.append(vehicle)

        for other_agent_id, other_agent_tup in self._agents.items():
            if other_agent_id == agent_id:
                continue

            _, other_vehicle = other_agent_tup
            vehicles.append(
                SocialVehicle.from_agent_vehicle(other_agent_id, other_vehicle))

        _, agent_vehicle = self._agents[agent_id]
        return self._neighborhood_vehicle_states(agent_vehicle.position,
                                                 radius,
                                                 vehicles)

    def reward(self):
        agent_rewards = {}
        for agent_id, agent_tup in self._agents.items():
            agent, vehicle = agent_tup
            agent_rewards[agent_id] = agent.reward(self, agent_id, vehicle)

        return SimulationReward(agent_rewards=agent_rewards)

    def observation(self):
        observations = {}
        for agent_id, agent_tup in self._agents.items():
            agent, vehicle = agent_tup
            observations[agent_id] = agent.observation(self, agent_id, vehicle)

        return SimulationObservation(agent_observations=observations)

    def add_road_network_from_egg(self, egg_path):
        np = self.attach_rigid_body_from_egg(egg_path, 'net')
        np.setTag(RenderTags.EXCLUDE_FROM_OCCUPANCY, str(True))
        return np

    def attach_rigid_body_from_egg(self, egg_path, name):
        self._log.debug('Loading %s rigid body from egg %s', name, egg_path)
        model_np = loader.loadModel(egg_path)
        self._log.debug('Finished loading model')

        bullet_node = BulletRigidBodyNode(name)
        for geom_np in model_np.findAllMatches('**/+GeomNode'):
            geom_node = geom_np.node()

            mesh = BulletTriangleMesh()
            for geom in geom_node.getGeoms():
                mesh.addGeom(geom)

            shape = BulletTriangleMeshShape(mesh, dynamic=False)
            bullet_node.addShape(shape)

        bullet_node_np = self._root_np.attachNewNode(bullet_node)
        model_np.reparent_to(bullet_node_np)

        self._log.debug('Attaching bullet_node to world')
        self._world.attach(bullet_node)
        self._log.debug('Done attaching rigid body %s', name)
        return bullet_node_np

    def add_agent(self, agent_id, agent: Agent, vehicle):
        assert agent_id not in self._agents
        assert isinstance(agent_id, str)  # SUMO expects strings identifiers

        agent.setup(self, agent_id, vehicle)
        self._agents[agent_id] = (agent, vehicle)

        self._agent_collisions[agent_id] = False

    def agent_did_collide(self, agent_id):
        return self._agent_collisions.get(agent_id, False)

    def is_agent_done(self, agent_id):
        agent, vehicle = self._agents[agent_id]
        return agent.is_done(self, agent_id, vehicle)

    def perform_agent_actions(self, agent_actions):
        for agent_id, action in agent_actions.items():
            assert agent_id in self._agents
            agent, vehicle = self._agents[agent_id]
            agent.perform_action(self, agent_id, vehicle, action)

    def make_vehicle(self, pos, heading=0):
        vehicle = Vehicle(pos, heading, self._world, self._root_np)
        vehicle.np.reparentTo(self._vehicles_np)
        return vehicle

    def _neighborhood_vehicle_states(self, center, radius, vehicles):
        """Convenience function to allow filtering the vehicle state list to
        those that are nearby an agent.
        """
        center = numpy.array(center)
        radius_squared = radius * radius

        filtered_vehicles = []
        for v in vehicles:
            if squared_dist(center, v.position) > radius_squared:
                continue
            v_wp = self.traffic_sim.waypoints.closest_waypoint(v.position)
            state = v.state(v_wp.lane_id, v_wp.lane_index)
            filtered_vehicles.append(state)

        return filtered_vehicles

    def _on_collision(self, cb_data):
        # `notifyCollisions(True)` has been set on the agent vehicles, so any collision
        # it gets into will trigger this method (this would include when it touches the
        # ground or other vehicles)
        if not (
            cb_data.node0.getPythonTag(Tags.VEHICLE_COLLISION) and
            cb_data.node1.getPythonTag(Tags.VEHICLE_COLLISION)
        ):
            # We are only concerned with vehicle-vehicle collisions
            return

        # There was a vehicle-vehicle collision, now we track which agents were involved
        for agent_id in self._agents.keys():
            _, vehicle = self._agents[agent_id]
            if vehicle.np.node() in [cb_data.node0, cb_data.node1]:
                self._agent_collisions[agent_id] = True

    def _setup_lighting(self):
        alight = AmbientLight('ambient_light')
        alight.setColor(Vec4(0.3, 0.3, 0.3, 1))
        alight_np = self._root_np.attachNewNode(alight)

        dlight = DirectionalLight('directional_light')
        dlight.setDirection(Vec3(1, 1, -1))
        dlight.setColor(Vec4(0.9, 0.9, 0.9, 1))
        dlight.setShadowCaster(True, 512, 512)
        dlight_np = self._root_np.attachNewNode(dlight)

        self._root_np.setLight(alight_np)
        self._root_np.setLight(dlight_np)
        self._root_np.setShaderAuto()
