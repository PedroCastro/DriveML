import numpy as np
import math


def squared_dist(a, b):
    """
    Computes the squared distance between a and b

    Params:
      a, b: same dimensional numpy.array([..])
    """
    delta = b - a
    return np.inner(delta, delta)

def signed_dist_to_line(point, line_point, line_dir_vec):
    """
    Computes the signed distance to a directed line

    The signed of the distance is:
      - negative if point is on the right of the line
      - positive if point is on the left of the line

    >>> import numpy as np
    >>> signed_dist_to_line(np.array([2, 0]), np.array([0, 0]), np.array([0, 1.]))
    -2.0
    >>> signed_dist_to_line(np.array([-1.5, 0]), np.array([0, 0]), np.array([0, 1.]))
    1.5
    """
    p = vec_2d(point)
    p1 = line_point
    p2 = line_point + line_dir_vec

    u =  abs(line_dir_vec[1] * p[0] - line_dir_vec[0] * p[1] \
             + p2[0] * p1[1] - p2[1] * p1[0])
    d = u / np.linalg.norm(line_dir_vec)

    line_normal = np.array([-line_dir_vec[1], line_dir_vec[0]])
    sign = np.sign(np.dot(p - p1, line_normal))
    return d * sign


def vec_2d(v):
    assert len(v) >= 2
    return np.array(v[:2])


def lerp(a, b, p):
    """
    linear interpolation between a and b with p
    """
    assert 0 <= p and p <= 1

    return a * (1. - p) + b * p


def degrees_to_vec(degrees):
    angle = math.radians(degrees)
    return np.array([math.cos(angle), math.sin(angle)])


def vec_to_degrees(v):
    # See: https://stackoverflow.com/questions/15126492/panda3d-how-to-rotate-object-so-that-its-x-axis-points-to-a-location-in-space/15130471#15130471
    assert len(v) == 2, f"Vector must be 2D: {repr(v)}"

    x, y = v
    r = math.atan2(abs(y), abs(x))
    a = math.degrees(r)

    quad = 0
    if x < 0:
        if y < 0:
            quad = 3
        else:
            quad = 2
    else:
        if y < 0:
            quad = 4

    # Adjust angle based on quadrant

    if 2 == quad:
        a = 180 - a
    elif 3 == quad:
        a = 180 + a
    elif 4 == quad:
        a = 360 - a

    return a


def trimf(x, a, b, c):
    """Triangular membership function generator. See
    https://www.mathworks.com/help/fuzzy/trimf.html for more context.

    Args:
      x: independent variable (1d array)
      a, b, c, d: x-position of triangle vertices. a <= b <= c <= d

    Returns:
      corresponding y values (1d array) at given x
    """
    assert a <= b and b <= c, 'a <= b <= c.'
    y = np.zeros(len(x))

    # Left side
    if a != b:
        idx = np.nonzero(np.logical_and(a < x, x < b))[0]
        y[idx] = (x[idx] - a) / float(b - a)

    # Right side
    if b != c:
        idx = np.nonzero(np.logical_and(b < x, x < c))[0]
        y[idx] = (c - x[idx]) / float(c - b)

    idx = np.nonzero(x == b)
    y[idx] = 1

    return y
