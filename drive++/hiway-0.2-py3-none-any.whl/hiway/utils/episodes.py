import os
import sys
import time
from contextlib import contextmanager


class Episode:
    def __init__(self, idx, max_iterations=None):
        self._idx = idx
        self._start_time = time.time()
        self._timers = {}
        self._statistics = {}
        self._rewards = {}
        self._iteration = 0
        self._max_iterations = max_iterations

        # The time when the previous iteration completed
        self._time_at_last_iteration = self._start_time

        # [0, 1] where 1 means that the new iteration time has no impact on the
        # current rate and 0 means historical iteration times have no impact on
        # the rate.
        self._iter_rate_recency_weight = 0.98

        # Rolling average of the iteration duration
        self._iter_duration_avg = 0

    @property
    def index(self):
        return self._idx

    @property
    def start_time(self):
        return self._start_time

    @property
    def elapsed_time(self):
        return time.time() - self._start_time

    @property
    def iteration(self):
        return self._iteration

    def update_statistic(self, name, value):
        self._statistics[name] = value

    @contextmanager
    def time(self, name):
        start = time.time()
        yield
        elapsed = time.time() - start
        self._timers[name] = elapsed

    def accumulate_reward(self, rewards):
        for instance, simulation_reward in rewards.items():
            if instance not in self._rewards:
                self._rewards[instance] = {}
            for agent, reward in simulation_reward.agent_rewards.items():
                if agent not in self._rewards[instance]:
                    self._rewards[instance][agent] = 0
                self._rewards[instance][agent] += reward

    def print_summary(self, replace_output=True):
        timer_summaries = [
            '{:.2f}s spent in {}'.format(duration, timer_name)
            for timer_name, duration in self._timers.items()
        ]

        statistic_summaries = [
            '{}: {}'.format(name, value)
            for name, value in self._statistics.items()]

        reward_summaries = []
        for instance, agents in self._rewards.items():
            for agent, reward in agents.items():
                reward_summaries.append(
                    '{}/{} accumulated {:.2f} reward'
                    .format(instance, agent, reward))

        summary = (
            "------------ episode ({:0=3d}) summary -----------\n"
            "{} iters in {:.2f} seconds\n"
            "{:.2f} iters/s\n"
            "{}\n"
            "{}"
            "{}"
        )

        if self._max_iterations is not None:
            summary += '\n' + self._pretty_progress(width=45)

        summary = summary.format(
            self._idx,
            self.iteration,
            self.elapsed_time,
            1 / self._iter_duration_avg,
            '\n'.join(timer_summaries),
            '\n'.join(statistic_summaries),
            '\n'.join(reward_summaries))

        if replace_output:
            if self.iteration % 50 == 0:
                os.system('clear')
                sys.stdout.write(summary)
                sys.stdout.flush()
        else:
            print(summary)
            print()

    def complete_iteration(self, print_summary=True, replace_output=True):
        self._iteration += 1

        # Record how long the last iteration took, then reset the timer
        new_iter_time = time.time() - self._time_at_last_iteration
        self._time_at_last_iteration = time.time()

        # Update rolling iteration rate average
        self._iter_duration_avg *= self._iter_rate_recency_weight
        self._iter_duration_avg += new_iter_time * (1 - self._iter_rate_recency_weight)

        if print_summary:
            self.print_summary(replace_output)

    def _pretty_progress(self, width=20):
        n = int(self._iteration * (width / self._max_iterations))
        fill = ''.join(['*'] * n)
        empty = ''.join([' '] * (width - n))
        return '[{}]'.format(fill + empty)


def episodes(n, max_step_length=None):
    for i in range(n):
        yield Episode(i, max_step_length)
