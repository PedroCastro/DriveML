from collections import namedtuple

import numpy

from panda3d.core import (
    NodePath,
    Vec3,
    TransformState,
    Point3,
)

from panda3d.bullet import (
    BulletBoxShape,
    BulletRigidBodyNode,
)

from .utils import abs_path
from .vehicle import Vehicle
from .sumo_traffic_simulation import TrafficSimVehicle
from .tags import Tags

SocialVehicleState = namedtuple(
    'SocialVehicleState',
    [
        'heading',
        'speed',
        'position',
        'lane_id',
        'lane_index',
        'bounding_box',
    ])

BoundingBox = namedtuple('BoundingBox', ['width', 'length', 'height'])


class SocialVehicle:
    def __init__(self, vehicle_id, speed=0.0, dim=(0.6, 1.4, 0.5), np=None):
        assert vehicle_id is not None
        self._id = vehicle_id
        self._speed = speed
        self._dim = dim
        self._sumo_pos = None

        if np is None:
            self._np = NodePath(BulletRigidBodyNode('vehicle-%s' % vehicle_id))
            self._np.setPythonTag(Tags.VEHICLE_COLLISION, True)
            self._np.node().addShape(
                BulletBoxShape(Vec3(*self._dim)),
                TransformState.makePos(Point3(0, 0, 0.5)))

            yugo_np = loader.load_model(abs_path('models/yugo/yugo.egg'))
            yugo_np.reparent_to(self._np)

            # tint social vehicles yellow to match their color in SUMO-GUI
            self._np.setColorScale(1.25, 2.5, 0., 1.)
        else:
            self._np = np

    def __repr__(self):
        return f"""SocialVehicle({self.id},
  position={self.position},
  heading={self.heading},
  speed={self.speed},
  w={self.width},
  l={self.length},
  h={self.height}
)"""

    @classmethod
    def from_agent_vehicle(cls, agent_id: str, v: Vehicle):
        return SocialVehicle(agent_id,
                             v.speed,
                             dim=(v.width, v.length, v.height),
                             np=v.np)

    @property
    def id(self):
        return self._id

    @property
    def np(self):
        return self._np

    @property
    def width(self):
        return self._dim[0]

    @property
    def length(self):
        return self._dim[1]

    @property
    def height(self):
        return self._dim[2]

    @property
    def position(self):
        if self._sumo_pos is not None:
            return self._sumo_pos
        else:
            x, y, _z = self._np.getBounds().getCenter()
            return numpy.array([x, y, 1.])

    @property
    def heading(self):
        return self.np.getH()

    @property
    def speed(self):
        return self._speed

    @property
    def bounding_box(self):
        return BoundingBox(width=self.width,
                           length=self.length,
                           height=self.height)

    def state(self, lane_id, lane_index):
        return SocialVehicleState(
            heading=self.heading,
            speed=self.speed,
            position=self.position,
            lane_id=lane_id,
            lane_index=lane_index,
            bounding_box=self.bounding_box)

    def teardown(self):
        self.np.removeNode()

    def update_from_traffic_sim(self, sumo_vehicle: TrafficSimVehicle):
        assert sumo_vehicle.vehicle_id == self._id

        x, y = sumo_vehicle.pos
        self._sumo_pos = numpy.array([x, y, 1])

        self._np.setPos(*self._sumo_pos)
        self._np.setH(sumo_vehicle.angle)
        self._speed = sumo_vehicle.speed
