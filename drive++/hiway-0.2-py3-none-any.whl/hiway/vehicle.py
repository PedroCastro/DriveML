import time
import math
from collections import namedtuple
from functools import partial
import logging

import numpy

from panda3d.core import (
    FrameBufferProperties,
    GraphicsOutput,
    GraphicsPipe,
    NodePath,
    OrthographicLens,
    Point3,
    Texture,
    TransformState,
    Vec3,
    WindowProperties,
    PandaNode,
)

from panda3d.bullet import (
    BulletBoxShape,
    BulletRigidBodyNode,
    BulletVehicle,
    ZUp
)

from .utils import abs_path
from .tags import RenderTags, Tags


OffscreenCamera = namedtuple(
    'OffscreenCamera', ['camera_np', 'buffer', 'tex'])

OccupancyGridMap = namedtuple(
    'OccupancyGridMap',
    ['metadata', 'data'])

OccupancyGridMetadata = namedtuple(
    'OccupancyGridMetadata',
    [
        # time at which the map was loaded
        'created_at',
        # map resolution in world-space-distance/cell
        'resolution',
        # map width in # of cells
        'width',
        # map height in # of cells
        'height'
    ])

VehicleState = namedtuple(
    'VehicleState',
    [
        'heading',
        'speed',
        'throttle',
        'brake',
        'steering',
        'position',
        'bounding_box'
    ])

BoundingBox = namedtuple('BoundingBox', ['width', 'length', 'height'])


class Vehicle():
    def __init__(self, pos, heading, bullet_world, scene_np):
        self._log = logging.getLogger(self.__class__.__name__)

        self._start_pos = pos
        self._start_heading = heading
        self._scene_np = scene_np
        self._max_engine_force = 2000  # TODO: what are units? newtons?
        self._max_brake_force = 100  # TODO: '' ^
        self._max_steering = 45.0  # degrees
        self._ogm = None
        self._rgb = None

        self._build_model(pos, heading, bullet_world)

    def _build_model(self, pos, heading, bullet_world):
        self._np = NodePath(BulletRigidBodyNode('vehicle'))
        self._np.setPythonTag(Tags.VEHICLE_COLLISION, True)

        self._np.node().addShape(
            BulletBoxShape(Vec3(self.width, self.length, self.height)),
            TransformState.makePos(Point3(0, 0, self.height)))

        self._np.setPos(*pos)
        self._np.setH(heading - 90)
        self._np.node().setMass(800.0)
        self._np.node().setDeactivationEnabled(False)
        self._np.node().notifyCollisions(True)

        # Bullet Vehicle
        self._bullet_vehicle = BulletVehicle(bullet_world, self._np.node())
        self._bullet_vehicle.setCoordinateSystem(ZUp)
        bullet_world.attach(self._bullet_vehicle)

        yugo_np = loader.loadModel(abs_path('models/yugo/yugo.egg'))
        yugo_np.reparentTo(self._np)

        wheel_x_offset = self.width + 0.1
        wheel_y_offset = self.length - 0.35
        wheel_z_offset = self.height - 0.2
        # Right front wheel
        wheels_config = [
            (
                abs_path('models/yugo/yugotireR.egg'), # front-right
                Point3(wheel_x_offset,  wheel_y_offset, wheel_z_offset),
                True
            ),
            (
                abs_path('models/yugo/yugotireL.egg'), # front-left
                Point3(-wheel_x_offset,  wheel_y_offset, wheel_z_offset),
                True
            ),
            (
                abs_path('models/yugo/yugotireR.egg'), # back-right
                Point3(wheel_x_offset, -wheel_y_offset, wheel_z_offset),
                False
            ),
            (
                abs_path('models/yugo/yugotireL.egg'), # back-left
                Point3(-wheel_x_offset, -wheel_y_offset, wheel_z_offset),
                False
            )
        ]

        for model_path, wheel_pos, is_front in wheels_config:
            # Right rear wheel
            wheel_np = loader.loadModel(model_path)
            wheel_np.reparentTo(self._np)

            wheel = self._bullet_vehicle.createWheel()

            wheel.setNode(wheel_np.node())
            wheel.setChassisConnectionPointCs(wheel_pos)
            wheel.setFrontWheel(is_front)

            wheel.setWheelDirectionCs(Vec3(0, 0, -1))
            wheel.setWheelAxleCs(Vec3(1, 0, 0))
            wheel.setWheelRadius(0.25)
            wheel.setMaxSuspensionTravelCm(40.0)

            wheel.setSuspensionStiffness(40.0)
            wheel.setWheelsDampingRelaxation(2.3)
            wheel.setWheelsDampingCompression(4.4)
            wheel.setFrictionSlip(100.0)
            wheel.setRollInfluence(0.1)

        # for some reason it matters that we attach the vehicle node here
        # after all initialization has been done
        bullet_world.attach(self._np.node())

    @property
    def length(self):
        return 1.4

    @property
    def width(self):
        return 0.6

    @property
    def height(self):
        return 0.5

    def teardown(self):
        if self._ogm:
            region = self._ogm.buffer.getDisplayRegion(0)
            region.window.clearRenderTextures()

        if self._rgb:
            region = self._rgb.buffer.getDisplayRegion(0)
            region.window.clearRenderTextures()

    def init_observation_ogm(self, width, height, resolution):
        assert self._ogm is None, 'OGM has already been initialized'
        self._ogm = self._build_offscreen_camera('ogm', width, height, resolution)
        self._perform_ogm_node_exclusions()

        # we need to force a render here  because we don't wait
        # a frame before observations are first computed.
        region = self._ogm.buffer.getDisplayRegion(0)
        region.window.engine.renderFrame()

        task = partial(self._camera_follow_vehicle, camera_np=self._ogm.camera_np)
        taskMgr.add(task, 'ogm-camera-follow', priority=35)

    def init_observation_rgb(self, width, height, resolution):
        assert self._rgb is None, 'RGB has already been initialized'
        self._rgb = self._build_offscreen_camera('rgb', width, height, resolution)
        self._perform_rgb_node_exclusions()

        region = self._rgb.buffer.getDisplayRegion(0)
        region.window.engine.renderFrame()

        task = partial(self._camera_follow_vehicle, camera_np=self._rgb.camera_np)
        taskMgr.add(task, 'rgb-camera-follow', priority=35)

    def calc_observation_ogm(self):
        assert self._ogm is not None, 'OGM has not been initialized'

        # because we render this map during the earlier render
        # cycle and then retrieve it from the cache, this object
        # exlusion is for the _next_ render cycle.
        self._perform_ogm_node_exclusions()

        ram_image = self._wait_for_ram_image(self._ogm)
        out = bytes(memoryview(ram_image))
        grid = numpy.frombuffer(out, numpy.uint8)
        grid.shape = (
            self._ogm.tex.getYSize(),
            self._ogm.tex.getXSize(),
            self._ogm.tex.getNumComponents())
        grid = numpy.flipud(grid)
        grid = (grid[:, :, 3]  # grab alpha channel
                .clip(min=0, max=1)
                .astype(numpy.int8))
        grid *= 100  # full confidence on known cells

        lens = self._ogm.camera_np.node().getLens(0)
        resolution = round(lens.getFilmSize().x / grid.shape[0], 5)

        metadata = OccupancyGridMetadata(
            created_at=int(time.time()),
            resolution=resolution,
            width=grid.shape[0],
            height=grid.shape[1])
        return OccupancyGridMap(data=grid, metadata=metadata)

    def calc_observation_rgb(self):
        assert self._rgb is not None, 'OGM has not been initialized'

        self._perform_rgb_node_exclusions()
        ram_image = self._wait_for_ram_image(self._rgb)
        out = bytes(memoryview(ram_image))
        image = numpy.frombuffer(out, numpy.uint8)
        image.shape = (
            self._rgb.tex.getYSize(),
            self._rgb.tex.getXSize(),
            self._rgb.tex.getNumComponents())
        image = numpy.flipud(image)
        image = image[:, :, :3]  # exclude alpha channel
        image = image[..., [2, 1, 0]]  # BRG --> RGB
        return image

    def _wait_for_ram_image(self, cam: OffscreenCamera, retries=10):
        # Rarely, we see dropped frames where an image is not available
        # for our observation calculations.
        #
        # We've seen this happen fairly reliable when we are initializing
        # a multi-agent + multi-instance simulation.
        #
        # To deal with this, we can try to force a render and block until
        # we are fairly certain we have an image in ram to return to the user
        for i in range(retries):
            if cam.tex.mightHaveRamImage():
                break
            self._log.warn(f"No image available (attempt {i}/{retries}), forcing a render")
            region = cam.buffer.getDisplayRegion(0)
            region.window.engine.renderFrame()

        assert cam.tex.mightHaveRamImage()
        ram_image = cam.tex.getRamImage()
        assert ram_image is not None
        return ram_image

    def _build_offscreen_camera(self, name, width, height, resolution):
        # setup buffer
        win_props = WindowProperties.size(width, height)
        fb_props = FrameBufferProperties()
        fb_props.setRgbColor(True)
        fb_props.setRgbaBits(8, 8, 8, 1)
        fb_props.setDepthBits(0)

        buffer = base.win.engine.makeOutput(
            base.pipe,
            '{}-buffer'.format(name),
            -100,
            fb_props,
            win_props,
            GraphicsPipe.BFRefuseWindow,
            base.win.getGsg(),
            base.win)

        # setup texture
        tex = Texture()
        region = buffer.getDisplayRegion(0)
        region.window.addRenderTexture(
            tex,
            GraphicsOutput.RTM_copy_ram,
            GraphicsOutput.RTP_color)

        # setup camera
        lens = OrthographicLens()
        lens.setFilmSize(width * resolution, height * resolution)

        camera_np = base.makeCamera(
            buffer, camName=name, scene=self._scene_np, lens=lens)
        camera_np.reparentTo(self._scene_np)

        return OffscreenCamera(camera_np, buffer, tex)

    def _perform_ogm_node_exclusions(self):
        self._hide_nodes_with_tag(
            self._ogm.camera_np,
            RenderTags.EXCLUDE_FROM_OCCUPANCY,
            unique_hide_mask=0x01)

    def _perform_rgb_node_exclusions(self):
        self._hide_nodes_with_tag(
            self._rgb.camera_np,
            RenderTags.EXCLUDE_FROM_RGBD,
            unique_hide_mask=0x02)

    def _hide_nodes_with_tag(self, camera_np, tag, unique_hide_mask):
        # reset/clear
        camera_np.node().setCameraMask(PandaNode.getAllCameraMask())

        np_collection = self._scene_np.findAllMatches(
            '**/={}={}'.format(tag, str(True)))

        for exclude_np in np_collection:
            exclude_np.hide(unique_hide_mask)

        camera_np.node().setCameraMask(
            camera_np.node().getCameraMask() & unique_hide_mask)

    def _camera_follow_vehicle(self, task, camera_np):
        center = self.position
        radius = min(self._local_bounds.getRadius(), 10000000)
        camera_np.setPos(center[0], center[1], 20 * radius)
        camera_np.lookAt(*center)
        camera_np.setH(self._np.getH())

        return task.cont

    @property
    def np(self):
        return self._np

    def state(self):
        return VehicleState(
            heading=self.heading,
            speed=self._bullet_vehicle.getCurrentSpeedKmHour(),
            throttle=self.throttle,
            brake=self.brake,
            steering=self.steering,
            position=self.position,
            bounding_box=BoundingBox(width=self.width,
                                     length=self.length,
                                     height=self.height))

    @property
    def speed(self):
        return self._bullet_vehicle.getCurrentSpeedKmHour()

    @property
    def heading(self):
        heading =  self._np.getH()
        heading += 90
        if heading < 0:
            heading += 360
        return heading

    @property
    def _local_bounds(self):
        return self._bullet_vehicle.getChassis().getShapeBounds()

    @property
    def position(self):
        pos = numpy.array(self._local_bounds.getCenter() + self._np.getPos())
        return pos

    @property
    def throttle(self):
        # we always apply the engine force (and brake) to both front wheels simultaneously
        wheel = self._bullet_vehicle.getWheel(2)
        return wheel.getEngineForce() / self._max_engine_force

    @property
    def brake(self):
        wheel = self._bullet_vehicle.getWheel(2)
        return wheel.getBrake() / self._max_brake_force

    @property
    def steering(self):
        wheel = self._bullet_vehicle.getWheel(0)
        return wheel.getSteering()

    def apply_throttle(self, activation):
        assert 0 <= activation and activation <= 1, 'activation must be in [0..1]'

        # apply engine force to back wheels
        engine_force = self._max_engine_force * activation
        self._bullet_vehicle.applyEngineForce(engine_force, 2)
        self._bullet_vehicle.applyEngineForce(engine_force, 3)

    def apply_brake(self, activation):
        assert 0 <= activation and activation <= 1, 'activation must be in [0..1]'

        brake_force = self._max_brake_force * activation
        self._bullet_vehicle.setBrake(brake_force, 2)
        self._bullet_vehicle.setBrake(brake_force, 3)

    def apply_steering(self, degrees):
        assert -45 <= degrees and degrees <= 45, 'degrees must be in [-45..45]'

        # steer front wheels
        self._bullet_vehicle.setSteeringValue(degrees, 0)
        self._bullet_vehicle.setSteeringValue(degrees, 1)
