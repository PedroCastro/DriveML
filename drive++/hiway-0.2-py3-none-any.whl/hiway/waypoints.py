from collections import namedtuple, defaultdict
import random

import numpy as np
from rtree import index

from .utils.math import (
    vec_to_degrees,
    degrees_to_vec,
    lerp,
    vec_2d,
    signed_dist_to_line
)


_WaypointBase = namedtuple(
    "_WaypointBase",
    ["id",           # int: numeric identifier for this waypoint
     "pos",          # np.array([x, y]): center point of lane
     "heading",      # float: heading angle of lane at this point (degrees)
     "lane_width",   # float: width of lane at this point (meters)
     "speed_limit",  # float: lane speed in km/h
     "lane_id",      # str: id of lane under waypoint
     "right_of_way", # bool: True if this waypoint has right of way, False otherwise
     "lane_index",   # int: Index of the lane this waypoint is over.
                     #      0 is the outer(right) most lane
    ])


class Waypoint(_WaypointBase):
    def dist_to(self, p):
        """
        Calculates straight line distance to the given 2D point
        """
        return np.linalg.norm(self.pos - vec_2d(p))

    def relative_heading(self, h):
        """
        Computes relative heading between the given angle and the waypoint heading
        Returns:
          relative_heading: -180..180
        """
        rel_heading = self.heading - h

        if rel_heading > 180:
            rel_heading -= 360
        if rel_heading < -180:
            rel_heading += 360

        return rel_heading

    def signed_lateral_error(self, p):
        """
        Returns the signed lateral distance from the given point to the
        line formed by the waypoint position and the waypoints heading.

        Negative signals right of line and Positive left of line
        """
        path_vector = degrees_to_vec(self.heading)
        return signed_dist_to_line(p, self.pos, path_vector)

LinkedWaypoint = namedtuple(
    "LinkedWaypoint",
    ["wp",    # Waypoint: current waypoint
     "nexts", # list of LinkedWaypoint: list of next immediate waypoints
              # it's a list of waypoints because a path may branch at junctions
    ])


class Waypoints:
    def __init__(self, road_network, spacing, debug=True):
        self._next_waypoint_id = 0
        self._road_network = road_network

        shape_wps = self._shape_waypoints()
        self._linked_waypoints = \
            self._interpolate_shape_waypoints(shape_wps, spacing)

        self._all_waypoints_index = index.Index()
        self._waypoints_by_lane_id_index = defaultdict(index.Index)
        for i, linked_wp in enumerate(self._linked_waypoints):
            x, y = linked_wp.wp.pos

            self._all_waypoints_index \
                .insert(i, (x, y, x, y))

            self._waypoints_by_lane_id_index[linked_wp.wp.lane_id] \
                .insert(i, (x, y, x, y))

        # TODO(drusu): we are disabling this validation for the competition
        # if debug:
        #     self._validate_lane_indices()

    def random_waypoint(self):
        return random.choice(self._linked_waypoints).wp

    def closest_waypoint(self, point):
        linked_waypoint = \
            self._closest_linked_wp_in_index(point, self._all_waypoints_index)
        return linked_waypoint.wp

    def closest_waypoint_on_lane(self, point, lane_id):
        lane_index = self._waypoints_by_lane_id_index[lane_id]
        linked_waypoint = \
            self._closest_linked_wp_in_index(point, lane_index)
        return linked_waypoint.wp

    def waypoint_paths_on_lane_at(self, point, lane_id, lookahead):
        lane_index = self._waypoints_by_lane_id_index[lane_id]
        linked_waypoint = \
            self._closest_linked_wp_in_index(point, lane_index)
        waypoint_paths = \
            self._waypoints_starting_at_waypoint(linked_waypoint, lookahead)

        # don't give users access to the linked structure
        unlinked_waypoint_paths = \
            [[linked_wp.wp for linked_wp in path] for path in waypoint_paths]
        return unlinked_waypoint_paths

    def waypoint_paths_at(self, point, lookahead):
        closest_linked_wp = \
            self._closest_linked_wp_in_index(point, self._all_waypoints_index)

        waypoint_paths = []
        try:
            # we don't have a good way of checking if lane_id is a SUMO lane_id,
            # the getLane will raise a KeyError if the lane id isn't a SUMO lane
            closest_lane = self._road_network \
                               .graph \
                               .getLane(closest_linked_wp.wp.lane_id)

            for lane in closest_lane.getEdge().getLanes():
                lane_id = lane.getID()
                waypoint_paths += \
                    self.waypoint_paths_on_lane_at(point, lane_id, lookahead)
        except KeyError:
            # the lane_id is not a SUMO lane id, this means it was a synthetic
            # lane created to join lanes across a junction
            waypoint_paths = \
                self.waypoint_paths_on_lane_at(point,
                                               closest_linked_wp.wp.lane_id,
                                               lookahead)

        sorted_wps = sorted(waypoint_paths, key=lambda p: p[0].lane_index)
        return sorted_wps

    def _validate_lane_indices(self):
        """
        Sanity check to make sure that all waypoints are tagged with
        lane_indices that are 0 in the right most lane and waypoint_paths
        returns paths ordered by lane index
        """
        for linked_wp in self._linked_waypoints:
            pos = linked_wp.wp.pos
            waypoint_paths = self.waypoint_paths_at(point=pos, lookahead=1)
            wps = [path[0] for path in waypoint_paths]
            sorted_wps = \
                sorted(wps, key=lambda wp: -wp.signed_lateral_error(pos))

            # validate that lane indices are 0 at right most lane and increment
            # to the left
            for i, wp in enumerate(sorted_wps):
                assert wp.lane_index == i

            # validate that the waypoint paths are ordered by lane_index
            for wp, sorted_wp in zip(wps, sorted_wps):
                assert wp.id == sorted_wp.id

    def _does_lane_have_right_of_way(self, lane):
        # This is hard coded for the competition scenario, we should use something like
        #  - prohibitions at the nearest intersection
        #  - Node.areFoes(lane1_index, lane2_index)
        return lane.getEdge().getPriority() > 1

    def _unique_waypoint_id(self):
        id_ = self._next_waypoint_id
        self._next_waypoint_id += 1
        return id_

    def _closest_linked_wp_in_index(self, point, index):
        x, y = vec_2d(point)
        closest_waypoint_idx = list(index.nearest((x, y, x, y), 1))[0]
        return self._linked_waypoints[closest_waypoint_idx]

    def _waypoints_starting_at_waypoint(self, waypoint: LinkedWaypoint, lookahead):
        waypoint_paths = [[waypoint]]
        for _ in range(lookahead):
            next_waypoint_paths = []
            for path in waypoint_paths:
                branching_paths = []
                for next_wp in path[-1].nexts:
                    new_path = path + [next_wp]
                    branching_paths.append(new_path)

                if branching_paths == []:
                    branching_paths = [path]

                next_waypoint_paths += branching_paths

            waypoint_paths = next_waypoint_paths

        return waypoint_paths

    def _interpolate_shape_waypoints(self, shape_waypoints, spacing):
        # memoize interpolated waypoints on the shape waypoint at start of
        # the line we are interpolating
        interp_memo = {}

        linked_waypoints = []
        for shape_wp in shape_waypoints:
            _, new_waypoints = \
                self._interpolate_from_shape_wp(shape_wp, spacing, interp_memo)
            linked_waypoints += new_waypoints

        return linked_waypoints

    def _interpolate_from_shape_wp(self, shape_wp, spacing, interp_memo):
        if shape_wp.wp.id in interp_memo:
            return interp_memo[shape_wp.wp.id], []

        first_linked_waypoint = \
            LinkedWaypoint(wp=Waypoint(id=self._unique_waypoint_id(),
                                       pos=shape_wp.wp.pos,
                                       heading=shape_wp.wp.heading,
                                       lane_width=shape_wp.wp.lane_width,
                                       speed_limit=shape_wp.wp.speed_limit,
                                       lane_id=shape_wp.wp.lane_id,
                                       lane_index=shape_wp.wp.lane_index,
                                       right_of_way=shape_wp.wp.right_of_way),
                           nexts=[])

        interp_memo[shape_wp.wp.id] = first_linked_waypoint

        newly_created_waypoints = [first_linked_waypoint]

        for next_shape_wp in shape_wp.nexts:
            if next_shape_wp.wp.lane_id == shape_wp.wp.lane_id:
                lane_id = shape_wp.wp.lane_id
                in_junction = False
            else:
                # here, we generate a synthetic lane id for the connection
                # between these waypoints since they are on two different lanes
                lane_id = f"junction::{next_shape_wp.wp.lane_id}::{shape_wp.wp.lane_id}"
                in_junction = True

            curr_waypoint = first_linked_waypoint

            lane_seg_vec = next_shape_wp.wp.pos - shape_wp.wp.pos
            lane_seg_len = np.linalg.norm(lane_seg_vec)

            # we set the initial distance into the lane at `spacing` because
            # we already have a waypoint along this segment (curr_waypoint)
            dist_into_lane_seg = spacing
            while dist_into_lane_seg < lane_seg_len:
                p = dist_into_lane_seg / lane_seg_len
                pos = shape_wp.wp.pos + lane_seg_vec * p
                heading = vec_to_degrees(lane_seg_vec)
                lane_width = \
                    lerp(shape_wp.wp.lane_width, next_shape_wp.wp.lane_width, p)
                speed_limit = \
                    lerp(shape_wp.wp.speed_limit, next_shape_wp.wp.speed_limit, p)

                # We don't consider the next_shape_wp.wp.right_of_way because you have the
                # right of way if the lane you started on has the right of way
                right_of_way = shape_wp.wp.right_of_way

                lane_index = 0 if in_junction else shape_wp.wp.lane_index

                linked_waypoint = \
                    LinkedWaypoint(wp=Waypoint(id=self._unique_waypoint_id(),
                                               pos=pos,
                                               heading=heading,
                                               lane_width=lane_width,
                                               speed_limit=speed_limit,
                                               lane_id=lane_id,
                                               lane_index=lane_index,
                                               right_of_way=right_of_way),
                                   nexts=[])

                curr_waypoint.nexts.append(linked_waypoint)
                curr_waypoint = linked_waypoint
                newly_created_waypoints.append(linked_waypoint)
                dist_into_lane_seg += spacing

            next_linked_waypoint, additional_newly_created_waypoints = \
                self._interpolate_from_shape_wp(next_shape_wp,
                                                              spacing,
                                                              interp_memo)

            curr_waypoint.nexts.append(next_linked_waypoint)
            newly_created_waypoints += additional_newly_created_waypoints

        return first_linked_waypoint, newly_created_waypoints

    def _shape_waypoints(self):
        """
        Computes the lane shape (start/shape/end) waypoints for all lanes in
        the network, the result of this function can be used to interpolate
        waypoints along lanes to the desired granularity.
        """
        edges = self._road_network.graph.getEdges()
        waypoint_by_lane_memo = {}
        shape_waypoints = []

        for edge in edges:
            for lane in edge.getLanes():
                _, new_wps = self._shape_waypoints_along_lane(lane, waypoint_by_lane_memo)
                shape_waypoints += new_wps

        return shape_waypoints

    def _shape_waypoints_along_lane(self, lane, waypoint_by_lane_memo):
        if lane.getID() in waypoint_by_lane_memo:
            # this function recurses on outgoing lane connections, this
            # is the terminating condition
            return waypoint_by_lane_memo[lane.getID()], []

        lane_data = self._road_network.lane_data_for_lane(lane)
        lane_shape = [np.array(p) for p in lane.getShape(False)]
        right_of_way = self._does_lane_have_right_of_way(lane)

        assert len(lane_shape) >= 2, repr(lane_shape)

        heading = vec_to_degrees(lane_shape[1] - lane_shape[0])

        first_waypoint = \
            LinkedWaypoint(wp=Waypoint(id=self._unique_waypoint_id(),
                                       pos=lane_shape[0],
                                       heading=heading,
                                       lane_width=lane.getWidth(),
                                       speed_limit=lane_data.lane_speed,
                                       lane_id=lane.getID(),
                                       lane_index=lane.getIndex(),
                                       right_of_way=right_of_way),
                           nexts=[])

        waypoint_by_lane_memo[lane.getID()] = first_waypoint
        shape_waypoints = [first_waypoint]
        curr_waypoint = first_waypoint
        for p1, p2 in zip(lane_shape[1:], lane_shape[2:]):
            linked_waypoint = \
                LinkedWaypoint(wp=Waypoint(id=self._unique_waypoint_id(),
                                           pos=p1,
                                           heading=vec_to_degrees(p2 - p1),
                                           lane_width=lane.getWidth(),
                                           speed_limit=lane_data.lane_speed,
                                           lane_id=lane.getID(),
                                           lane_index=lane.getIndex(),
                                           right_of_way=right_of_way),
                               nexts=[])

            shape_waypoints.append(linked_waypoint)
            curr_waypoint.nexts.append(linked_waypoint)
            curr_waypoint = linked_waypoint

        # Add a waypoint for the last point of the current lane
        last_linked_waypoint = \
            LinkedWaypoint(wp=Waypoint(id=self._unique_waypoint_id(),
                                       pos=lane_shape[-1],
                                       heading=curr_waypoint.wp.heading,
                                       lane_width=curr_waypoint.wp.lane_width,
                                       speed_limit=curr_waypoint.wp.speed_limit,
                                       lane_id=curr_waypoint.wp.lane_id,
                                       lane_index=curr_waypoint.wp.lane_index,
                                       right_of_way=right_of_way),
                           nexts=[])

        shape_waypoints.append(last_linked_waypoint)
        curr_waypoint.nexts.append(last_linked_waypoint)
        curr_waypoint = last_linked_waypoint

        for out_connection in lane.getOutgoing():
            out_lane = out_connection.getToLane()
            next_wp, new_wps = self._shape_waypoints_along_lane(out_lane, waypoint_by_lane_memo)
            curr_waypoint.nexts.append(next_wp)
            shape_waypoints += new_wps

        return first_waypoint, shape_waypoints
